// server/index.ts
import "dotenv/config";
import express2 from "express";

// server/routes.ts
import { createServer } from "http";
import { promises as fsPromises } from "fs";
import * as fs3 from "fs";
import path2 from "path";

// server/db.ts
import sql from "mssql";
var fullServer = process.env.DB_SERVER || "WEB-APP-INSTANC\\SQLEXPRESS04";
var serverParts = fullServer.split("\\");
var serverHost = serverParts[0];
var instanceName = serverParts.length > 1 ? serverParts[1] : void 0;
var sqlConfig = {
  user: process.env.DB_USER || "sa",
  password: process.env.DB_PASSWORD || "Cybaem@123",
  database: process.env.DB_NAME || "DMS",
  server: serverHost,
  // Only set port when NOT using a named instance (port & instanceName are mutually exclusive)
  ...instanceName ? {} : { port: parseInt(process.env.DB_PORT || "1433", 10) },
  options: {
    ...instanceName ? { instanceName } : {},
    encrypt: false,
    // Use true if using Azure SQL
    trustServerCertificate: true,
    // For local/self-signed certs
    enableArithAbort: true
  },
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 3e4
  }
};
var poolPromise = null;
function getPool() {
  if (!poolPromise) {
    poolPromise = new sql.ConnectionPool(sqlConfig).connect().then((pool) => {
      console.log("Connected to SQL Server successfully");
      return pool;
    }).catch((err) => {
      console.error("SQL Server connection error:", err);
      poolPromise = null;
      throw err;
    });
  }
  return poolPromise;
}

// server/storage.ts
import fs from "fs";

// shared/locationUtils.ts
function parseLocations(loc) {
  if (!loc) return ["all"];
  const trimmed = loc.trim().toLowerCase();
  if (!trimmed || trimmed === "all" || trimmed === "common") {
    return ["all"];
  }
  const parts = loc.split(",").map((p) => p.trim().toLowerCase()).filter(Boolean);
  if (parts.length === 0 || parts.includes("all") || parts.includes("common")) {
    return ["all"];
  }
  return parts;
}
function locationsOverlap(loc1, loc2) {
  if (loc1 === void 0 || loc2 === void 0) {
    return true;
  }
  const list1 = parseLocations(loc1);
  const list2 = parseLocations(loc2);
  if (list1.includes("all") || list2.includes("all")) {
    return true;
  }
  return list1.some((l1) => list2.includes(l1));
}
function getOverlappingUnits(loc1, loc2) {
  const list1 = parseLocations(loc1);
  const list2 = parseLocations(loc2);
  if (list1.includes("all") && list2.includes("all")) {
    return ["All Locations"];
  }
  if (list1.includes("all")) {
    return list2.map(formatUnitName);
  }
  if (list2.includes("all")) {
    return list1.map(formatUnitName);
  }
  const common = list1.filter((l1) => list2.includes(l1));
  return common.map(formatUnitName);
}
function formatUnitName(u) {
  if (u.toLowerCase() === "ho") return "HO";
  if (u.toLowerCase() === "all") return "All Locations";
  return u.split(" ").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
}
function filterLatestDocuments(documents) {
  if (!documents || documents.length === 0) return [];
  const sorted = [...documents].sort((a, b) => {
    const revA = a.revisionNo !== void 0 && a.revisionNo !== null ? Number(a.revisionNo) : -1;
    const revB = b.revisionNo !== void 0 && b.revisionNo !== null ? Number(b.revisionNo) : -1;
    if (revB !== revA) return revB - revA;
    const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return timeB - timeA;
  });
  const kept = [];
  for (const doc of sorted) {
    const docNum = (doc.docNumber || "").trim().toLowerCase();
    if (!docNum) {
      kept.push(doc);
      continue;
    }
    const hasNewerOverlapping = kept.some((k) => {
      const kDocNum = (k.docNumber || "").trim().toLowerCase();
      if (kDocNum !== docNum) return false;
      return locationsOverlap(k.location, doc.location);
    });
    if (!hasNewerOverlapping) {
      kept.push(doc);
    }
  }
  return kept.sort((a, b) => {
    const timeA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
    const timeB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
    return timeB - timeA;
  });
}

// server/storage.ts
var debugLog = (msg) => {
  const logPath = "c:\\inetpub\\wwwroot\\dms\\debug.log";
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  try {
    fs.appendFileSync(logPath, `[${timestamp}] ${msg}
`);
  } catch (e) {
    console.error("Failed to write to debug log", e);
  }
};
function mapUser(row) {
  const location = row.location || row.Location || row.LOCATION || null;
  return {
    id: row.id,
    username: row.username,
    password: row.password,
    role: row.role,
    fullName: row.full_name || row.fullName,
    masterCopyAccess: row.master_copy_access === true || row.master_copy_access === 1 || row.masterCopyAccess === true,
    departmentId: row.department_id || row.departmentId || null,
    departmentName: row.department_name || row.departmentName || null,
    departmentCode: row.department_code || row.departmentCode || null,
    location: typeof location === "string" ? location.trim() : location
  };
}
function mapDepartment(row) {
  return {
    id: row.id,
    name: row.name,
    code: row.code,
    category: row.category || null,
    categoryName: row.category_name || null,
    createdAt: row.created_at
  };
}
function mapDocument(row) {
  return {
    id: row.id,
    docName: row.doc_name,
    docNumber: row.doc_number,
    status: row.status ? row.status.trim() : "pending",
    dateOfIssue: row.date_of_issue || null,
    revisionNo: row.revision_no || 0,
    preparedBy: row.prepared_by,
    approvedBy: row.approved_by || null,
    issuedBy: row.issued_by || null,
    content: row.content || null,
    headerInfo: row.header_info || null,
    footerInfo: row.footer_info || null,
    duePeriodYears: row.due_period_years || null,
    reasonForRevision: row.reason_for_revision || null,
    reviewDueDate: row.review_due_date || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    approvedAt: row.approved_at || null,
    issuedAt: row.issued_at || null,
    approvalRemarks: row.approval_remarks || null,
    declineRemarks: row.decline_remarks || null,
    issueRemarks: row.issue_remarks || null,
    issuerName: row.issuer_name || null,
    previousVersionId: row.previous_version_id || null,
    pdfFilePath: row.pdf_file_path || null,
    wordFilePath: row.word_file_path || null,
    creatorData: row.creator_data ? typeof row.creator_data === "string" ? JSON.parse(row.creator_data) : row.creator_data : null,
    approverData: row.approver_data ? typeof row.approver_data === "string" ? JSON.parse(row.approver_data) : row.approver_data : null,
    issuerData: row.issuer_data ? typeof row.issuer_data === "string" ? JSON.parse(row.issuer_data) : row.issuer_data : null,
    originalDateOfIssue: row.original_date_of_issue || null,
    preparerName: row.preparer_name || null,
    approverName: row.approver_name || null,
    pageCount: row.page_count || null,
    location: row.location || null,
    dateOfRev: row.date_of_rev || null,
    issueNo: row.issue_no || null,
    declinedBy: row.declined_by || null,
    declinerName: row.decliner_name || null,
    declinedAt: row.declined_at || null
  };
}
function mapNotification(row) {
  return {
    id: row.id,
    userId: row.user_id,
    documentId: row.document_id,
    message: row.message,
    type: row.type,
    isRead: row.is_read === true || row.is_read === 1,
    createdAt: row.created_at
  };
}
function mapControlCopy(row) {
  return {
    id: row.id,
    documentId: row.document_id,
    userId: row.user_id,
    copyNumber: row.copy_number,
    actionType: row.action_type,
    generatedAt: row.generated_at
  };
}
function mapPrintLog(row) {
  return {
    id: row.id,
    documentId: row.document_id,
    userId: row.user_id,
    controlCopyId: row.control_copy_id,
    printedAt: row.printed_at,
    medium: row.medium || null
  };
}
function mapDocumentRecipient(row) {
  return {
    id: row.id,
    documentId: row.document_id,
    userId: row.user_id || null,
    departmentId: row.department_id || null,
    notifiedAt: row.notified_at,
    readAt: row.read_at || null
  };
}
function generateId(prefix = "") {
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 8);
  return prefix ? `${prefix}-${timestamp}-${random}` : `${timestamp}-${random}`;
}
var SqlServerStorage = class {
  // =============================================
  // Users
  // =============================================
  async getUserByUsername(username) {
    const pool = await getPool();
    const result = await pool.request().input("username", sql.NVarChar, username).query("SELECT id, username, password, role, full_name, master_copy_access, department_id, department_name, department_code, location FROM users WHERE username = @username");
    return result.recordset.length > 0 ? mapUser(result.recordset[0]) : void 0;
  }
  async getUser(id) {
    const pool = await getPool();
    const result = await pool.request().input("id", sql.NVarChar, id).query("SELECT id, username, password, role, full_name, master_copy_access, department_id, department_name, department_code, location FROM users WHERE id = @id");
    return result.recordset.length > 0 ? mapUser(result.recordset[0]) : void 0;
  }
  async createUser(insertUser) {
    const pool = await getPool();
    const rolePrefix = {
      "creator": "CA",
      "approver": "AD",
      "issuer": "IA",
      "admin": "AM",
      "recipient": "RC"
    };
    const prefix = rolePrefix[insertUser.role || "creator"] || "US";
    const countResult = await pool.request().input("prefix", sql.NVarChar, `${prefix}-%`).query("SELECT id FROM users WHERE id LIKE @prefix");
    let nextNumber = 1;
    if (countResult.recordset.length > 0) {
      const numbers = countResult.recordset.map((r) => {
        const match = r.id.match(new RegExp(`^${prefix}-(\\d+)$`));
        return match ? parseInt(match[1], 10) : 0;
      }).filter((num) => !isNaN(num));
      if (numbers.length > 0) {
        nextNumber = Math.max(...numbers) + 1;
      }
    }
    const userId = `${prefix}-${nextNumber.toString().padStart(3, "0")}`;
    let deptId = insertUser.departmentId;
    if (deptId === "") deptId = null;
    let deptName = insertUser.departmentName || null;
    let deptCode = insertUser.departmentCode || null;
    if (deptId && (!deptName || !deptCode)) {
      const deptResult = await pool.request().input("id", sql.NVarChar, deptId).query("SELECT name, code FROM departments WHERE id = @id");
      if (deptResult.recordset.length > 0) {
        deptName = deptResult.recordset[0].name;
        deptCode = deptResult.recordset[0].code;
      }
    }
    await pool.request().input("id", sql.NVarChar, userId).input("username", sql.NVarChar, insertUser.username).input("password", sql.NVarChar, insertUser.password).input("role", sql.NVarChar, insertUser.role || "creator").input("fullName", sql.NVarChar, insertUser.fullName).input("masterCopyAccess", sql.Bit, insertUser.masterCopyAccess ? 1 : 0).input("departmentId", sql.NVarChar, deptId).input("departmentName", sql.NVarChar, deptName).input("departmentCode", sql.NVarChar, deptCode).input("location", sql.NVarChar, insertUser.location || null).query(`INSERT INTO users (id, username, password, role, full_name, master_copy_access, department_id, department_name, department_code, location)
              VALUES (@id, @username, @password, @role, @fullName, @masterCopyAccess, @departmentId, @departmentName, @departmentCode, @location)`);
    return await this.getUser(userId);
  }
  async updateUser(id, updates) {
    const pool = await getPool();
    const existing = await this.getUser(id);
    if (!existing) throw new Error(`User with id ${id} not found`);
    const setClauses = [];
    const request = pool.request().input("id", sql.NVarChar, id);
    if (updates.username !== void 0) {
      setClauses.push("username = @username");
      request.input("username", sql.NVarChar, updates.username);
    }
    if (updates.password !== void 0 && updates.password !== "") {
      setClauses.push("password = @password");
      request.input("password", sql.NVarChar, updates.password);
    }
    if (updates.role !== void 0) {
      setClauses.push("role = @role");
      request.input("role", sql.NVarChar, updates.role);
    }
    if (updates.fullName !== void 0) {
      setClauses.push("full_name = @fullName");
      request.input("fullName", sql.NVarChar, updates.fullName);
    }
    if (updates.masterCopyAccess !== void 0) {
      setClauses.push("master_copy_access = @masterCopyAccess");
      request.input("masterCopyAccess", sql.Bit, updates.masterCopyAccess ? 1 : 0);
    }
    let deptId = updates.departmentId;
    if (deptId === "") deptId = null;
    if (updates.departmentId !== void 0) {
      setClauses.push("department_id = @departmentId");
      request.input("departmentId", sql.NVarChar, deptId);
      if (deptId) {
        const deptResult = await pool.request().input("did", sql.NVarChar, deptId).query("SELECT name, code FROM departments WHERE id = @did");
        if (deptResult.recordset.length > 0) {
          const d = deptResult.recordset[0];
          setClauses.push("department_name = @dn");
          request.input("dn", sql.NVarChar, d.name);
          setClauses.push("department_code = @dc");
          request.input("dc", sql.NVarChar, d.code);
        }
      } else {
        setClauses.push("department_name = NULL");
        setClauses.push("department_code = NULL");
      }
    } else {
      if (updates.departmentName !== void 0) {
        setClauses.push("department_name = @departmentName");
        request.input("departmentName", sql.NVarChar, updates.departmentName);
      }
      if (updates.departmentCode !== void 0) {
        setClauses.push("department_code = @departmentCode");
        request.input("departmentCode", sql.NVarChar, updates.departmentCode);
      }
    }
    if (updates.location !== void 0) {
      setClauses.push("location = @location");
      request.input("location", sql.NVarChar, updates.location);
    }
    if (setClauses.length > 0) {
      await request.query(`UPDATE users SET ${setClauses.join(", ")} WHERE id = @id`);
    }
    return this.getUser(id);
  }
  async deleteUser(id) {
    const pool = await getPool();
    const result = await pool.request().input("id", sql.NVarChar, id).query("DELETE FROM users WHERE id = @id");
    if (result.rowsAffected[0] === 0) {
      throw new Error(`User with id ${id} not found`);
    }
  }
  async getUsersByRole(role) {
    const pool = await getPool();
    const result = await pool.request().input("role", sql.NVarChar, role).query("SELECT * FROM users WHERE role = @role");
    return result.recordset.map(mapUser);
  }
  // =============================================
  // Documents
  // =============================================
  async getDocument(id) {
    const pool = await getPool();
    const result = await pool.request().input("id", sql.NVarChar, id).query("SELECT * FROM documents WHERE id = @id");
    return result.recordset.length > 0 ? mapDocument(result.recordset[0]) : void 0;
  }
  async getDocumentsByStatus(status, latestOnly = false) {
    const pool = await getPool();
    const query = "SELECT * FROM documents WHERE status = @status ORDER BY created_at DESC";
    const result = await pool.request().input("status", sql.NVarChar, status).query(query);
    const docs = result.recordset.map(mapDocument);
    if (latestOnly && status === "issued") {
      return filterLatestDocuments(docs);
    }
    return docs;
  }
  async getDocumentsByUser(userId) {
    const pool = await getPool();
    const result = await pool.request().input("userId", sql.NVarChar, userId).query(`SELECT * FROM documents 
              WHERE prepared_by = @userId 
                 OR prepared_by IN (SELECT username FROM users WHERE id = @userId)
                 OR prepared_by IN (SELECT full_name FROM users WHERE id = @userId)
                 OR preparer_name IN (SELECT full_name FROM users WHERE id = @userId)
              ORDER BY created_at DESC`);
    return result.recordset.map(mapDocument);
  }
  async getDocumentsByDocNumber(docNumber, location) {
    const pool = await getPool();
    const request = pool.request().input("docNumber", sql.NVarChar, docNumber.trim());
    const query = "SELECT * FROM documents WHERE RTRIM(LTRIM(LOWER(doc_number))) = RTRIM(LTRIM(LOWER(@docNumber))) ORDER BY revision_no DESC";
    const result = await request.query(query);
    const docs = result.recordset.map(mapDocument);
    if (location !== void 0) {
      return docs.filter((d) => locationsOverlap(d.location, location));
    }
    return docs;
  }
  async getDocumentRevisions(docNumber, location) {
    const docs = await this.getDocumentsByDocNumber(docNumber, location);
    return docs.sort((a, b) => (Number(a.revisionNo) || 0) - (Number(b.revisionNo) || 0));
  }
  async getGlobalNextRevisionNo(docNumber, location) {
    if (!docNumber || docNumber.trim() === "") return 0;
    const docs = await this.getDocumentsByDocNumber(docNumber, location);
    if (docs.length === 0) return 0;
    const maxRev = Math.max(...docs.map((d) => Number(d.revisionNo) || 0));
    return maxRev >= 0 ? maxRev + 1 : 0;
  }
  async obsoleteSupersededIssuedDocuments(docNumber, location, keepDocId) {
    const docs = await this.getDocumentsByDocNumber(docNumber, location);
    const issuedDocs = docs.filter((d) => (d.status || "").toLowerCase().trim() === "issued");
    if (issuedDocs.length <= 1) return 0;
    let activeDoc;
    if (keepDocId) {
      activeDoc = issuedDocs.find((d) => d.id === keepDocId);
    }
    if (!activeDoc) {
      activeDoc = [...issuedDocs].sort((a, b) => (Number(b.revisionNo) || 0) - (Number(a.revisionNo) || 0))[0];
    }
    let obsoletedCount = 0;
    for (const doc of issuedDocs) {
      if (doc.id !== activeDoc.id && (Number(doc.revisionNo) || 0) < (Number(activeDoc.revisionNo) || 0)) {
        console.log(`[Storage] Auto-marking superseded version ${doc.revisionNo} (${doc.id}) of ${docNumber} at ${doc.location || "All"} as obsolete`);
        await this.updateDocument(doc.id, { status: "obsolete" });
        obsoletedCount++;
      }
    }
    return obsoletedCount;
  }
  async cleanUpAllSupersededIssuedDocuments() {
    try {
      const pool = await getPool();
      const result = await pool.request().query("SELECT * FROM documents WHERE status = 'issued'");
      const issuedDocs = result.recordset.map(mapDocument);
      const groups = /* @__PURE__ */ new Map();
      for (const doc of issuedDocs) {
        const num = (doc.docNumber || "").trim().toLowerCase();
        if (!num) continue;
        if (!groups.has(num)) groups.set(num, []);
        groups.get(num).push(doc);
      }
      let obsoletedCount = 0;
      for (const docs of Array.from(groups.values())) {
        if (docs.length <= 1) continue;
        const sorted = [...docs].sort((a, b) => {
          const revA = Number(a.revisionNo) || 0;
          const revB = Number(b.revisionNo) || 0;
          if (revB !== revA) return revB - revA;
          return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
        });
        for (let i = 1; i < sorted.length; i++) {
          const lowerDoc = sorted[i];
          const hasHigherOverlapping = sorted.slice(0, i).some(
            (higherDoc) => locationsOverlap(higherDoc.location, lowerDoc.location)
          );
          if (hasHigherOverlapping) {
            console.log(`[Storage] Auto-cleaning superseded issued doc ${lowerDoc.id} (${lowerDoc.docName}, docNo: ${lowerDoc.docNumber}, rev: ${lowerDoc.revisionNo}, loc: ${lowerDoc.location}) -> obsolete`);
            await this.updateDocument(lowerDoc.id, { status: "obsolete" });
            obsoletedCount++;
          }
        }
      }
      if (obsoletedCount > 0) {
        console.log(`[Storage] Cleaned up ${obsoletedCount} superseded issued document(s) to obsolete.`);
      }
      return obsoletedCount;
    } catch (err) {
      console.error("[Storage] Error in cleanUpAllSupersededIssuedDocuments:", err);
      return 0;
    }
  }
  async getDocumentsByDepartment(departmentId, status, latestOnly = false) {
    const pool = await getPool();
    const request = pool.request().input("departmentId", sql.NVarChar, departmentId);
    let query = `SELECT DISTINCT d.* FROM documents d
                 WHERE (
                   EXISTS (
                     SELECT 1 FROM document_departments dd
                     WHERE dd.document_id = d.id AND dd.department_id = @departmentId
                   )
                   OR d.prepared_by IN (
                     SELECT id FROM users WHERE department_id = @departmentId
                   )
                   OR d.creator_data LIKE '%"departmentId":"' + @departmentId + '"%'
                 )`;
    if (status) {
      query += ` AND d.status = @status`;
      request.input("status", sql.NVarChar, status);
    }
    query += ` ORDER BY d.created_at DESC`;
    const result = await request.query(query);
    const docs = result.recordset.map(mapDocument);
    if (latestOnly && status === "issued") {
      return filterLatestDocuments(docs);
    }
    return docs;
  }
  async createDocument(insertDocument) {
    const pool = await getPool();
    const docId = `doc-${Date.now()}`;
    await pool.request().input("id", sql.NVarChar, docId).input("docName", sql.NVarChar, insertDocument.docName).input("docNumber", sql.NVarChar, insertDocument.docNumber).input("status", sql.NVarChar, insertDocument.status || "pending").input("dateOfIssue", sql.DateTime2, insertDocument.dateOfIssue ? new Date(insertDocument.dateOfIssue) : /* @__PURE__ */ new Date()).input("revisionNo", sql.Int, Number(insertDocument.revisionNo) || 0).input("preparedBy", sql.NVarChar, insertDocument.preparedBy).input("approvedBy", sql.NVarChar, insertDocument.approvedBy || null).input("issuedBy", sql.NVarChar, insertDocument.issuedBy || null).input("content", sql.NVarChar(sql.MAX), insertDocument.content || null).input("headerInfo", sql.NVarChar(sql.MAX), insertDocument.headerInfo || null).input("footerInfo", sql.NVarChar(sql.MAX), insertDocument.footerInfo || null).input("duePeriodYears", sql.Int, Number(insertDocument.duePeriodYears) || null).input("reasonForRevision", sql.NVarChar(sql.MAX), insertDocument.reasonForRevision || null).input("reviewDueDate", sql.DateTime2, insertDocument.reviewDueDate ? new Date(insertDocument.reviewDueDate) : null).input("approvalRemarks", sql.NVarChar(sql.MAX), insertDocument.approvalRemarks || null).input("declineRemarks", sql.NVarChar(sql.MAX), insertDocument.declineRemarks || null).input("previousVersionId", sql.NVarChar, insertDocument.previousVersionId || null).input("pdfFilePath", sql.NVarChar, insertDocument.pdfFilePath || null).input("wordFilePath", sql.NVarChar, insertDocument.wordFilePath || null).input("creatorData", sql.NVarChar(sql.MAX), insertDocument.creatorData ? JSON.stringify(insertDocument.creatorData) : null).input("issueNo", sql.NVarChar, insertDocument.issueNo || null).input("originalDateOfIssue", sql.DateTime2, insertDocument.originalDateOfIssue ? new Date(insertDocument.originalDateOfIssue) : null).input("preparerName", sql.NVarChar, insertDocument.preparerName || null).input("approverName", sql.NVarChar, insertDocument.approverName || null).input("pageCount", sql.Int, insertDocument.pageCount || null).input("location", sql.NVarChar, insertDocument.location || null).input("dateOfRev", sql.DateTime2, insertDocument.dateOfRev ? new Date(insertDocument.dateOfRev) : null).input("declinedBy", sql.NVarChar, insertDocument.declinedBy || null).input("declinerName", sql.NVarChar, insertDocument.declinerName || null).input("declinedAt", sql.DateTime2, insertDocument.declinedAt ? new Date(insertDocument.declinedAt) : null).query(`INSERT INTO documents (id, doc_name, doc_number, status, date_of_issue, revision_no, prepared_by, approved_by, issued_by, content, header_info, footer_info, due_period_years, reason_for_revision, review_due_date, approval_remarks, decline_remarks, previous_version_id, pdf_file_path, word_file_path, creator_data, issue_no, original_date_of_issue, preparer_name, approver_name, page_count, location, date_of_rev, declined_by, decliner_name, declined_at)
              VALUES (@id, @docName, @docNumber, @status, @dateOfIssue, @revisionNo, @preparedBy, @approvedBy, @issuedBy, @content, @headerInfo, @footerInfo, @duePeriodYears, @reasonForRevision, @reviewDueDate, @approvalRemarks, @declineRemarks, @previousVersionId, @pdfFilePath, @wordFilePath, @creatorData, @issueNo, @originalDateOfIssue, @preparerName, @approverName, @pageCount, @location, @dateOfRev, @declinedBy, @declinerName, @declinedAt)`);
    return await this.getDocument(docId);
  }
  async updateDocument(id, updates) {
    const pool = await getPool();
    const existing = await this.getDocument(id);
    if (!existing) return void 0;
    const setClauses = [];
    const request = pool.request().input("id", sql.NVarChar(sql.MAX), id);
    console.log(`[Storage] Updating document ${id} with:`, updates);
    if (updates.docName !== void 0) {
      setClauses.push("doc_name = @docName");
      request.input("docName", sql.NVarChar(sql.MAX), updates.docName);
    }
    if (updates.docNumber !== void 0) {
      setClauses.push("doc_number = @docNumber");
      request.input("docNumber", sql.NVarChar(sql.MAX), updates.docNumber);
    }
    if (updates.status !== void 0) {
      setClauses.push("status = @status");
      request.input("status", sql.NVarChar(sql.MAX), updates.status);
    }
    if (updates.dateOfIssue !== void 0) {
      setClauses.push("date_of_issue = @dateOfIssue");
      request.input("dateOfIssue", sql.DateTime2, updates.dateOfIssue ? new Date(updates.dateOfIssue) : null);
    }
    if (updates.revisionNo !== void 0) {
      setClauses.push("revision_no = @revisionNo");
      request.input("revisionNo", sql.Int, updates.revisionNo);
    }
    if (updates.preparedBy !== void 0) {
      setClauses.push("prepared_by = @preparedBy");
      request.input("preparedBy", sql.NVarChar(sql.MAX), updates.preparedBy);
    }
    if (updates.approvedBy !== void 0) {
      setClauses.push("approved_by = @approvedBy");
      request.input("approvedBy", sql.NVarChar(sql.MAX), updates.approvedBy);
    }
    if (updates.issuedBy !== void 0) {
      setClauses.push("issued_by = @issuedBy");
      request.input("issuedBy", sql.NVarChar(sql.MAX), updates.issuedBy);
    }
    if (updates.content !== void 0) {
      setClauses.push("content = @content");
      request.input("content", sql.NVarChar(sql.MAX), updates.content);
    }
    if (updates.headerInfo !== void 0) {
      setClauses.push("header_info = @headerInfo");
      request.input("headerInfo", sql.NVarChar(sql.MAX), updates.headerInfo);
    }
    if (updates.footerInfo !== void 0) {
      setClauses.push("footer_info = @footerInfo");
      request.input("footerInfo", sql.NVarChar(sql.MAX), updates.footerInfo);
    }
    if (updates.duePeriodYears !== void 0) {
      setClauses.push("due_period_years = @duePeriodYears");
      request.input("duePeriodYears", sql.Int, updates.duePeriodYears);
    }
    if (updates.reasonForRevision !== void 0) {
      setClauses.push("reason_for_revision = @reasonForRevision");
      request.input("reasonForRevision", sql.NVarChar(sql.MAX), updates.reasonForRevision);
    }
    if (updates.reviewDueDate !== void 0) {
      setClauses.push("review_due_date = @reviewDueDate");
      request.input("reviewDueDate", sql.DateTime2, updates.reviewDueDate ? new Date(updates.reviewDueDate) : null);
    }
    if (updates.approvedAt !== void 0) {
      setClauses.push("approved_at = @approvedAt");
      request.input("approvedAt", sql.DateTime2, updates.approvedAt ? new Date(updates.approvedAt) : null);
    }
    if (updates.issuedAt !== void 0) {
      setClauses.push("issued_at = @issuedAt");
      request.input("issuedAt", sql.DateTime2, updates.issuedAt ? new Date(updates.issuedAt) : null);
    }
    if (updates.approvalRemarks !== void 0) {
      setClauses.push("approval_remarks = @approvalRemarks");
      request.input("approvalRemarks", sql.NVarChar(sql.MAX), updates.approvalRemarks);
    }
    if (updates.declineRemarks !== void 0) {
      setClauses.push("decline_remarks = @declineRemarks");
      request.input("declineRemarks", sql.NVarChar(sql.MAX), updates.declineRemarks);
    }
    if (updates.issueRemarks !== void 0) {
      setClauses.push("issue_remarks = @issueRemarks");
      request.input("issueRemarks", sql.NVarChar(sql.MAX), updates.issueRemarks);
    }
    if (updates.issuerName !== void 0) {
      setClauses.push("issuer_name = @issuerName");
      request.input("issuerName", sql.NVarChar(sql.MAX), updates.issuerName);
    }
    if (updates.previousVersionId !== void 0) {
      setClauses.push("previous_version_id = @previousVersionId");
      request.input("previousVersionId", sql.NVarChar(sql.MAX), updates.previousVersionId);
    }
    if (updates.pdfFilePath !== void 0) {
      setClauses.push("pdf_file_path = @pdfFilePath");
      request.input("pdfFilePath", sql.NVarChar(sql.MAX), updates.pdfFilePath);
    }
    if (updates.wordFilePath !== void 0) {
      setClauses.push("word_file_path = @wordFilePath");
      request.input("wordFilePath", sql.NVarChar(sql.MAX), updates.wordFilePath);
    }
    if (updates.creatorData !== void 0) {
      setClauses.push("creator_data = @creatorData");
      request.input("creatorData", sql.NVarChar(sql.MAX), updates.creatorData ? JSON.stringify(updates.creatorData) : null);
    }
    if (updates.approverData !== void 0) {
      setClauses.push("approver_data = @approverData");
      request.input("approverData", sql.NVarChar(sql.MAX), updates.approverData ? JSON.stringify(updates.approverData) : null);
    }
    if (updates.issuerData !== void 0) {
      setClauses.push("issuer_data = @issuerData");
      request.input("issuerData", sql.NVarChar(sql.MAX), updates.issuerData ? JSON.stringify(updates.issuerData) : null);
    }
    if (updates.issueNo !== void 0) {
      setClauses.push("issue_no = @issueNo");
      request.input("issueNo", sql.NVarChar(sql.MAX), updates.issueNo);
    }
    if (updates.originalDateOfIssue !== void 0) {
      setClauses.push("original_date_of_issue = @originalDateOfIssue");
      request.input("originalDateOfIssue", sql.DateTime2, updates.originalDateOfIssue ? new Date(updates.originalDateOfIssue) : null);
    }
    if (updates.preparerName !== void 0) {
      setClauses.push("preparer_name = @preparerName");
      request.input("preparerName", sql.NVarChar(sql.MAX), updates.preparerName);
    }
    if (updates.approverName !== void 0) {
      setClauses.push("approver_name = @approverName");
      request.input("approverName", sql.NVarChar(sql.MAX), updates.approverName);
    }
    if (updates.pageCount !== void 0) {
      setClauses.push("page_count = @pageCount");
      request.input("pageCount", sql.Int, updates.pageCount);
    }
    if (updates.location !== void 0) {
      setClauses.push("location = @location");
      request.input("location", sql.NVarChar(sql.MAX), updates.location);
    }
    if (updates.dateOfRev !== void 0) {
      setClauses.push("date_of_rev = @dateOfRev");
      request.input("dateOfRev", sql.DateTime2, updates.dateOfRev ? new Date(updates.dateOfRev) : null);
    }
    if (updates.declinedBy !== void 0) {
      setClauses.push("declined_by = @declinedBy");
      request.input("declinedBy", sql.NVarChar(sql.MAX), updates.declinedBy);
    }
    if (updates.declinerName !== void 0) {
      setClauses.push("decliner_name = @declinerName");
      request.input("declinerName", sql.NVarChar(sql.MAX), updates.declinerName);
    }
    if (updates.declinedAt !== void 0) {
      setClauses.push("declined_at = @declinedAt");
      request.input("declinedAt", sql.DateTime2, updates.declinedAt ? new Date(updates.declinedAt) : null);
    }
    setClauses.push("updated_at = GETDATE()");
    if (setClauses.length > 0) {
      const query = `UPDATE documents SET ${setClauses.join(", ")} WHERE id = @id`;
      debugLog(`[Storage] Executing: ${query}`);
      await request.query(query);
    }
    return this.getDocument(id);
  }
  // =============================================
  // Departments
  // =============================================
  async getDepartments() {
    const pool = await getPool();
    const result = await pool.request().query("SELECT * FROM departments ORDER BY name");
    return result.recordset.map(mapDepartment);
  }
  async createDepartment(insertDepartment) {
    const pool = await getPool();
    const deptId = `dept-${Date.now()}`;
    await pool.request().input("id", sql.NVarChar, deptId).input("name", sql.NVarChar, insertDepartment.name).input("code", sql.NVarChar, insertDepartment.code || "").input("category", sql.NVarChar, insertDepartment.category || null).input("categoryName", sql.NVarChar, insertDepartment.categoryName || null).query("INSERT INTO departments (id, name, code, category, category_name) VALUES (@id, @name, @code, @category, @categoryName)");
    const result = await pool.request().input("id", sql.NVarChar, deptId).query("SELECT * FROM departments WHERE id = @id");
    return mapDepartment(result.recordset[0]);
  }
  async deleteDepartment(id) {
    const pool = await getPool();
    await pool.request().input("departmentId", sql.NVarChar, id).query("DELETE FROM document_departments WHERE department_id = @departmentId");
    const result = await pool.request().input("id", sql.NVarChar, id).query("DELETE FROM departments WHERE id = @id");
    if (result.rowsAffected[0] === 0) {
      throw new Error(`Department with id ${id} not found`);
    }
  }
  // =============================================
  // Document-Department Assignments
  // =============================================
  async assignDocumentToDepartments(documentId, departmentIds) {
    const pool = await getPool();
    await pool.request().input("documentId", sql.NVarChar, documentId).query("DELETE FROM document_departments WHERE document_id = @documentId");
    for (const deptId of departmentIds) {
      await pool.request().input("id", sql.NVarChar, generateId("dd")).input("documentId", sql.NVarChar, documentId).input("departmentId", sql.NVarChar, deptId).query("INSERT INTO document_departments (id, document_id, department_id) VALUES (@id, @documentId, @departmentId)");
    }
  }
  async getDocumentDepartments(documentId) {
    const pool = await getPool();
    const result = await pool.request().input("documentId", sql.NVarChar, documentId).query(`SELECT d.* FROM departments d
              INNER JOIN document_departments dd ON d.id = dd.department_id
              WHERE dd.document_id = @documentId`);
    return result.recordset.map(mapDepartment);
  }
  // =============================================
  // Notifications
  // =============================================
  async createNotification(insertNotification) {
    const pool = await getPool();
    const notifId = generateId("notif");
    await pool.request().input("id", sql.NVarChar, notifId).input("userId", sql.NVarChar, insertNotification.userId).input("documentId", sql.NVarChar, insertNotification.documentId).input("message", sql.NVarChar(sql.MAX), insertNotification.message).input("type", sql.NVarChar, insertNotification.type).query("INSERT INTO notifications (id, user_id, document_id, message, type) VALUES (@id, @userId, @documentId, @message, @type)");
    const result = await pool.request().input("id", sql.NVarChar, notifId).query("SELECT * FROM notifications WHERE id = @id");
    return mapNotification(result.recordset[0]);
  }
  async getUserNotifications(userId) {
    const pool = await getPool();
    const result = await pool.request().input("userId", sql.NVarChar, userId).query("SELECT * FROM notifications WHERE user_id = @userId ORDER BY created_at DESC");
    return result.recordset.map(mapNotification);
  }
  async markNotificationAsRead(id) {
    const pool = await getPool();
    await pool.request().input("id", sql.NVarChar, id).query("UPDATE notifications SET is_read = 1 WHERE id = @id");
  }
  // =============================================
  // Control Copies
  // =============================================
  async createControlCopy(insertControlCopy) {
    const pool = await getPool();
    const ccId = generateId("cc");
    const copyNumber = await this.getNextCopyNumber(insertControlCopy.documentId, insertControlCopy.userId);
    await pool.request().input("id", sql.NVarChar, ccId).input("documentId", sql.NVarChar, insertControlCopy.documentId).input("userId", sql.NVarChar, insertControlCopy.userId).input("copyNumber", sql.Int, copyNumber).input("actionType", sql.NVarChar, insertControlCopy.actionType).query("INSERT INTO control_copies (id, document_id, user_id, copy_number, action_type) VALUES (@id, @documentId, @userId, @copyNumber, @actionType)");
    const result = await pool.request().input("id", sql.NVarChar, ccId).query("SELECT * FROM control_copies WHERE id = @id");
    return mapControlCopy(result.recordset[0]);
  }
  async getControlCopiesByDocument(documentId) {
    const pool = await getPool();
    const result = await pool.request().input("documentId", sql.NVarChar, documentId).query("SELECT * FROM control_copies WHERE document_id = @documentId ORDER BY generated_at DESC");
    return result.recordset.map(mapControlCopy);
  }
  async getControlCopiesByUser(userId) {
    const pool = await getPool();
    const result = await pool.request().input("userId", sql.NVarChar, userId).query("SELECT * FROM control_copies WHERE user_id = @userId ORDER BY generated_at DESC");
    return result.recordset.map(mapControlCopy);
  }
  async getNextCopyNumber(documentId, userId) {
    const pool = await getPool();
    const result = await pool.request().input("documentId", sql.NVarChar, documentId).input("userId", sql.NVarChar, userId).query("SELECT MAX(copy_number) as maxCopy FROM control_copies WHERE document_id = @documentId AND user_id = @userId");
    return (result.recordset[0].maxCopy || 0) + 1;
  }
  // =============================================
  // Print Logs
  // =============================================
  async createPrintLog(insertPrintLog) {
    const pool = await getPool();
    const plId = generateId("pl");
    await pool.request().input("id", sql.NVarChar, plId).input("documentId", sql.NVarChar, insertPrintLog.documentId).input("userId", sql.NVarChar, insertPrintLog.userId).input("controlCopyId", sql.NVarChar, insertPrintLog.controlCopyId).input("medium", sql.NVarChar, insertPrintLog.medium || null).query("INSERT INTO print_logs (id, document_id, user_id, control_copy_id, medium) VALUES (@id, @documentId, @userId, @controlCopyId, @medium)");
    const result = await pool.request().input("id", sql.NVarChar, plId).query("SELECT * FROM print_logs WHERE id = @id");
    return mapPrintLog(result.recordset[0]);
  }
  async getPrintLogsByDocument(documentId) {
    const pool = await getPool();
    const result = await pool.request().input("documentId", sql.NVarChar, documentId).query("SELECT * FROM print_logs WHERE document_id = @documentId ORDER BY printed_at DESC");
    return result.recordset.map(mapPrintLog);
  }
  async getPrintLogsByUser(userId) {
    const pool = await getPool();
    const result = await pool.request().input("userId", sql.NVarChar, userId).query("SELECT * FROM print_logs WHERE user_id = @userId ORDER BY printed_at DESC");
    return result.recordset.map(mapPrintLog);
  }
  // =============================================
  // Document Recipients
  // =============================================
  async createDocumentRecipient(insertRecipient) {
    const pool = await getPool();
    if (!insertRecipient.userId && !insertRecipient.departmentId) {
      throw new Error("Document recipient must have either userId or departmentId");
    }
    const drId = generateId("dr");
    await pool.request().input("id", sql.NVarChar, drId).input("documentId", sql.NVarChar, insertRecipient.documentId).input("userId", sql.NVarChar, insertRecipient.userId || null).input("departmentId", sql.NVarChar, insertRecipient.departmentId || null).query("INSERT INTO document_recipients (id, document_id, user_id, department_id) VALUES (@id, @documentId, @userId, @departmentId)");
    const result = await pool.request().input("id", sql.NVarChar, drId).query("SELECT * FROM document_recipients WHERE id = @id");
    return mapDocumentRecipient(result.recordset[0]);
  }
  async getDocumentRecipients(documentId) {
    const pool = await getPool();
    const result = await pool.request().input("documentId", sql.NVarChar, documentId).query("SELECT * FROM document_recipients WHERE document_id = @documentId");
    return result.recordset.map(mapDocumentRecipient);
  }
  async getUserAccessibleDocuments(userId) {
    const pool = await getPool();
    const result = await pool.request().input("userId", sql.NVarChar, userId).query(`SELECT DISTINCT d.* FROM documents d
               INNER JOIN document_recipients dr ON d.id = dr.document_id
               LEFT JOIN users u ON u.id = @userId
               WHERE (dr.user_id = @userId OR dr.department_id = u.department_id)
               AND d.status = 'issued'
               AND d.revision_no = (
                 SELECT MAX(d2.revision_no)
                 FROM documents d2
                 WHERE TRIM(d2.doc_number) = TRIM(d.doc_number) 
                 AND ISNULL(d2.location, '') = ISNULL(d.location, '')
                 AND d2.status = 'issued'
               )
               ORDER BY d.created_at DESC`);
    return result.recordset.map(mapDocument);
  }
  async hasUserPrintedDocument(userId, documentId) {
    const pool = await getPool();
    const result = await pool.request().input("userId", sql.NVarChar, userId).input("documentId", sql.NVarChar, documentId).query("SELECT TOP 1 id FROM print_logs WHERE user_id = @userId AND document_id = @documentId");
    return result.recordset.length > 0;
  }
  async deleteDocument(id) {
    const pool = await getPool();
    const doc = await this.getDocument(id);
    if (!doc) throw new Error(`Document with id ${id} not found`);
    await pool.request().input("docId", sql.NVarChar, id).query("DELETE FROM document_departments WHERE document_id = @docId");
    await pool.request().input("docId", sql.NVarChar, id).query("DELETE FROM notifications WHERE document_id = @docId");
    await pool.request().input("docId", sql.NVarChar, id).query("DELETE FROM document_recipients WHERE document_id = @docId");
    await pool.request().input("docId", sql.NVarChar, id).query("DELETE FROM print_logs WHERE document_id = @docId");
    await pool.request().input("docId", sql.NVarChar, id).query("DELETE FROM control_copies WHERE document_id = @docId");
    const result = await pool.request().input("id", sql.NVarChar, id).query("DELETE FROM documents WHERE id = @id");
    if (result.rowsAffected[0] === 0) {
      throw new Error(`Failed to delete document ${id}`);
    }
  }
  // =============================================
  // App Settings
  // =============================================
  async getSetting(key) {
    const pool = await getPool();
    const result = await pool.request().input("key", sql.NVarChar, key).query("SELECT * FROM app_settings WHERE setting_key = @key");
    if (result.recordset.length > 0) {
      const row = result.recordset[0];
      return {
        id: row.id,
        settingKey: row.setting_key,
        settingValue: row.setting_value,
        description: row.description,
        updatedAt: row.updated_at
      };
    }
    return void 0;
  }
  async updateSetting(key, value) {
    const pool = await getPool();
    const existing = await this.getSetting(key);
    if (existing) {
      await pool.request().input("key", sql.NVarChar, key).input("value", sql.NVarChar, value).query("UPDATE app_settings SET setting_value = @value, updated_at = GETDATE() WHERE setting_key = @key");
    } else {
      await pool.request().input("key", sql.NVarChar, key).input("value", sql.NVarChar, value).query("INSERT INTO app_settings (setting_key, setting_value, description) VALUES (@key, @value, 'Auto-generated setting')");
    }
    return await this.getSetting(key);
  }
};
var storage = new SqlServerStorage();

// server/routes.ts
import multer from "multer";

// server/services/pdf-service.ts
import mammoth from "mammoth";
import puppeteer from "puppeteer";
import { PDFDocument } from "pdf-lib";
import path from "path";
import fs2 from "fs/promises";
import { existsSync } from "fs";
import { exec } from "child_process";
import { promisify } from "util";
import { fileURLToPath } from "url";
import AdmZipPackage from "adm-zip";
var execAsync = promisify(exec);
var AdmZip = AdmZipPackage.default || AdmZipPackage;
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var baseDir = process.cwd();
var PDFService = class {
  uploadsDir = path.join(baseDir, "uploads");
  pdfsDir = path.join(baseDir, "pdfs");
  constructor() {
  }
  async initialize() {
    await this.ensureDirectories();
  }
  async ensureDirectories() {
    await fs2.mkdir(this.uploadsDir, { recursive: true });
    await fs2.mkdir(this.pdfsDir, { recursive: true });
  }
  sanitizeFilename(name) {
    return name.replace(/[/\\?%*:|"<>]/g, "-").replace(/\s+/g, "_");
  }
  async convertWordToPDF(wordFilePath, document, controlCopyInfo) {
    try {
      console.log(`[PDF] Starting High-Fidelity STAMPING conversion for ${document.docNumber}`);
      const originalPdfPath = await this.convertWordToNativePdfWithLibreOffice(wordFilePath);
      const originalPdfBytes = await fs2.readFile(originalPdfPath);
      const stampsPdfPath = await this.generateStampsOnlyPdf(document, originalPdfBytes, controlCopyInfo);
      const stampsPdfBytes = await fs2.readFile(stampsPdfPath);
      const mergedPdfPath = await this.mergeAndScalePdfs(originalPdfBytes, stampsPdfBytes, document);
      try {
        await fs2.unlink(originalPdfPath);
        await fs2.unlink(stampsPdfPath);
      } catch (e) {
      }
      return mergedPdfPath;
    } catch (err) {
      console.error(`[PDF] CRITICAL HIGH-FIDELITY FAILURE for ${document.docNumber}:`, err);
      console.warn(`[PDF] High-Fidelity Conversion failed: ${err.message}. Falling back to standard conversion...`);
      return await this.convertWordToPDFWithPuppeteer(wordFilePath, document, controlCopyInfo);
    }
  }
  async convertWordToNativePdfWithLibreOffice(wordFilePath) {
    const libreOfficePath = process.env.LIBREOFFICE_PATH || "C:\\Program Files\\LibreOffice\\program\\soffice.exe";
    if (!existsSync(libreOfficePath)) throw new Error("LibreOffice not found");
    const uniqueId = Math.random().toString(36).substring(2, 10);
    const tempOutputDir = path.join(this.pdfsDir, `stamp_temp_${Date.now()}_${uniqueId}`);
    await fs2.mkdir(tempOutputDir, { recursive: true });
    try {
      const safeInputPath = path.join(tempOutputDir, `input.docx`);
      try {
        const buffer = await fs2.readFile(wordFilePath);
        const zip = new AdmZip(buffer);
        const docXmlEntry = zip.getEntry("word/document.xml");
        if (docXmlEntry) {
          let docXml = docXmlEntry.getData().toString("utf8");
          docXml = docXml.replace(/<w:pgMar([^>]*)\/?>/g, (match, attrs) => {
            let newAttrs = attrs;
            newAttrs = newAttrs.replace(/w:top="[0-9]+"/, 'w:top="2155"');
            newAttrs = newAttrs.replace(/w:bottom="[0-9]+"/, 'w:bottom="1701"');
            newAttrs = newAttrs.replace(/w:left="[0-9]+"/, 'w:left="737"');
            newAttrs = newAttrs.replace(/w:right="[0-9]+"/, 'w:right="567"');
            if (!newAttrs.includes("w:top=")) newAttrs += ' w:top="2155"';
            if (!newAttrs.includes("w:bottom=")) newAttrs += ' w:bottom="1701"';
            if (!newAttrs.includes("w:left=")) newAttrs += ' w:left="737"';
            if (!newAttrs.includes("w:right=")) newAttrs += ' w:right="567"';
            if (newAttrs.endsWith("/")) newAttrs = newAttrs.slice(0, -1);
            return `<w:pgMar${newAttrs}/>`;
          });
          docXml = docXml.replace(/<w:tblPr\b[^>]*>([\s\S]*?)<\/w:tblPr>/g, (match, inner) => {
            let newInner = inner.replace(/<w:tblW[^>]*\/?>(?:<\/w:tblW>)?/g, '<w:tblW w:w="5000" w:type="pct"/>');
            newInner = newInner.replace(/<w:tblInd[^>]*\/?>(?:<\/w:tblInd>)?/g, '<w:tblInd w:w="0" w:type="dxa"/>');
            return match.replace(inner, newInner);
          });
          zip.updateFile("word/document.xml", Buffer.from(docXml, "utf8"));
          await fs2.writeFile(safeInputPath, zip.toBuffer());
        } else {
          await fs2.copyFile(wordFilePath, safeInputPath);
        }
      } catch (e) {
        console.warn("[PDF] Failed to inject dynamic margins, falling back to original file:", e);
        await fs2.copyFile(wordFilePath, safeInputPath);
      }
      const command = `"${libreOfficePath}" --headless --convert-to pdf --outdir "${tempOutputDir}" "${safeInputPath}"`;
      console.log(`[PDF] Executing: ${command}`);
      const { stdout, stderr } = await execAsync(command, { timeout: 60 * 1e3 });
      if (stderr) console.warn(`[PDF] LibreOffice stderr: ${stderr}`);
      if (stdout) console.log(`[PDF] LibreOffice stdout: ${stdout}`);
      const pdfPath = path.join(tempOutputDir, "input.pdf");
      let retries = 0;
      while (!existsSync(pdfPath) && retries < 20) {
        await new Promise((resolve) => setTimeout(resolve, 500));
        retries++;
      }
      if (!existsSync(pdfPath)) throw new Error("LibreOffice PDF output not found after conversion");
      const finalPath = path.join(this.pdfsDir, `native_${Date.now()}_${uniqueId}.pdf`);
      await fs2.rename(pdfPath, finalPath);
      return finalPath;
    } finally {
      try {
        await fs2.rm(tempOutputDir, { recursive: true, force: true });
      } catch (e) {
      }
    }
  }
  async generateStampsOnlyPdf(document, originalPdfBytes, controlCopyInfo) {
    const originalPdf = await PDFDocument.load(originalPdfBytes);
    const pageCount = originalPdf.getPageCount();
    const tempMerged = await PDFDocument.create();
    const embeddedPages = await tempMerged.embedPages(originalPdf.getPages());
    const trueWidth = embeddedPages[0].width;
    const trueHeight = embeddedPages[0].height;
    const headerHtml = this.getHeaderTemplate(document);
    const footerHtml = this.getFooterTemplate(document, controlCopyInfo);
    let browser;
    try {
      browser = await puppeteer.launch({
        headless: true,
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH,
        args: ["--no-sandbox", "--disable-setuid-sandbox"]
      });
      const page = await browser.newPage();
      let contentHtml = '<div style="font-size: 1px;">';
      for (let i = 0; i < pageCount; i++) {
        contentHtml += `<div style="height: 1px; color: transparent; ${i < pageCount - 1 ? "page-break-after: always;" : ""}">.</div>`;
      }
      contentHtml += "</div>";
      await page.setContent(contentHtml, { waitUntil: "load" });
      const stampsPdfPath = path.join(this.pdfsDir, `stamps_${Date.now()}.pdf`);
      const pdfBuffer = await page.pdf({
        width: `${trueWidth / 72}in`,
        height: `${trueHeight / 72}in`,
        displayHeaderFooter: true,
        headerTemplate: headerHtml,
        footerTemplate: footerHtml,
        printBackground: true,
        margin: {
          top: "3.8cm",
          bottom: "3cm",
          left: "1.3cm",
          right: "1cm"
        }
      });
      await fs2.writeFile(stampsPdfPath, pdfBuffer);
      return stampsPdfPath;
    } finally {
      if (browser) await browser.close();
    }
  }
  async mergeAndScalePdfs(originalBytes, stampsBytes, document) {
    const originalPdf = await PDFDocument.load(originalBytes);
    const stampsPdf = await PDFDocument.load(stampsBytes);
    const mergedPdf = await PDFDocument.create();
    const originalPages = originalPdf.getPages();
    const stampPages = stampsPdf.getPages();
    const embeddedOriginalPages = await mergedPdf.embedPages(originalPages);
    const embeddedStampPages = await mergedPdf.embedPages(stampPages);
    for (let i = 0; i < embeddedOriginalPages.length; i++) {
      const orig = embeddedOriginalPages[i];
      const stamp = i < embeddedStampPages.length ? embeddedStampPages[i] : embeddedStampPages[embeddedStampPages.length - 1];
      const width = orig.width;
      const height = orig.height;
      const newPage = mergedPdf.addPage([width, height]);
      newPage.drawPage(orig, {
        x: 0,
        y: 0,
        width,
        height
      });
      newPage.drawPage(stamp, { x: 0, y: 0, width, height });
    }
    const safeDocNumber = this.sanitizeFilename(document.docNumber);
    const finalName = `${safeDocNumber}_v${document.revisionNo}_final_${Date.now()}.pdf`;
    const finalPath = path.join(this.pdfsDir, finalName);
    const mergedBytes = await mergedPdf.save();
    await fs2.writeFile(finalPath, mergedBytes);
    return finalPath;
  }
  async detectIsLandscape(wordFilePath) {
    try {
      if (!wordFilePath.endsWith(".docx")) return false;
      const buffer = await fs2.readFile(wordFilePath);
      const zip = new AdmZip(buffer);
      const docXml = zip.readAsText("word/document.xml");
      if (docXml.includes('w:orient="landscape"') || docXml.includes('orient="landscape"')) {
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }
  async convertWordToHtmlWithLibreOffice(wordFilePath) {
    if (!existsSync(wordFilePath)) throw new Error("Word file not found");
    const libreOfficePath = process.env.LIBREOFFICE_PATH || "C:\\Program Files\\LibreOffice\\program\\soffice.exe";
    if (!existsSync(libreOfficePath)) throw new Error("LibreOffice not found");
    const outputDir = path.join(this.pdfsDir, `temp_${Date.now()}`);
    await fs2.mkdir(outputDir, { recursive: true });
    try {
      const command = `"${libreOfficePath}" --headless --convert-to "html:HTML:EmbedImages" --outdir "${outputDir}" "${wordFilePath}"`;
      console.log(`[PDF] Executing LibreOffice to HTML: ${command}`);
      await execAsync(command, { timeout: 6e4 });
      const tempHtmlName = path.basename(wordFilePath, path.extname(wordFilePath)) + ".html";
      const tempHtmlPath = path.join(outputDir, tempHtmlName);
      let retries = 0;
      while (!existsSync(tempHtmlPath) && retries < 20) {
        await new Promise((resolve) => setTimeout(resolve, 500));
        retries++;
      }
      if (!existsSync(tempHtmlPath)) throw new Error("HTML conversion failed");
      let html = await fs2.readFile(tempHtmlPath, "utf-8");
      const bodyMatch = html.match(/<body[^>]*>([\s\S]*)<\/body>/i);
      const innerContent = bodyMatch ? bodyMatch[1] : html;
      const scrubbedContent = innerContent.replace(/@page\s*\{[\s\S]*?\}/gi, "").replace(/body\s*\{margin:[^;]+;?\}/gi, "").replace(/<(meta|title|link|xml)[^>]*>([\s\S]*?)<\/\1>/gi, "");
      const headMatch = html.match(/<head[^>]*>([\s\S]*)<\/head>/i);
      const headContent = headMatch ? headMatch[1] : "";
      const styleMatch = headContent.match(/<style[^>]*>([\s\S]*?)<\/style>/gi);
      const styles = styleMatch ? styleMatch.join("\n") : "";
      return `
        ${styles}
        <div class="libre-content">${scrubbedContent}</div>`;
    } finally {
      try {
        await fs2.rm(outputDir, { recursive: true, force: true });
      } catch (rmErr) {
        console.warn(`[PDF] Failed to cleanup temp dir: ${outputDir}`);
      }
    }
  }
  async generatePdfFromHtml(bodyHtml, document, isLandscape = false, controlCopyInfo) {
    let browser;
    try {
      const width = isLandscape ? 841.89 : 595.28;
      const height = isLandscape ? 595.28 : 841.89;
      const fullHtml = this.wrapWithHeavyDutyTheme(document, bodyHtml, isLandscape, width, height, controlCopyInfo);
      browser = await puppeteer.launch({
        headless: true,
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH,
        args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"]
      });
      const page = await browser.newPage();
      await page.setContent(fullHtml, { waitUntil: "load" });
      const headerHtml = this.getHeaderTemplate(document);
      const footerHtml = this.getFooterTemplate(document, controlCopyInfo);
      const safeDocNumber = this.sanitizeFilename(document.docNumber);
      const pdfFileName = `${safeDocNumber}_v${document.revisionNo}_issued_${Date.now()}.pdf`;
      const pdfPath = path.join(this.pdfsDir, pdfFileName);
      const pdfBuffer = await page.pdf({
        printBackground: true,
        preferCSSPageSize: false,
        displayHeaderFooter: true,
        headerTemplate: headerHtml,
        footerTemplate: footerHtml,
        width: `${width / 72}in`,
        height: `${height / 72}in`,
        landscape: isLandscape,
        margin: {
          top: "3.8cm",
          bottom: "3cm",
          left: "1.3cm",
          right: "1cm"
        }
      });
      await fs2.writeFile(pdfPath, pdfBuffer);
      return pdfPath;
    } finally {
      if (browser) await browser.close();
    }
  }
  async convertWordToPDFWithPuppeteer(wordFilePath, document, controlCopyInfo) {
    try {
      const isLandscape = await this.detectIsLandscape(wordFilePath);
      const wordBuffer = await fs2.readFile(wordFilePath);
      const result = await mammoth.convertToHtml({ buffer: wordBuffer });
      const htmlContent = result.value || "";
      return await this.generatePdfFromHtml(htmlContent, document, isLandscape, controlCopyInfo);
    } catch (err) {
      console.error("[PDF] Critical Fallback Failure:", err);
      throw err;
    }
  }
  wrapWithHeavyDutyTheme(document, body, isLandscape, width, height, controlCopyInfo) {
    return `
<!DOCTYPE html>
<html>
<head>
  <style>
    /* RESET CSS to match Word behavior */
    * { box-sizing: border-box; }
    html, body { 
      margin: 0; 
      padding: 0; 
      width: 100%; 
      -webkit-print-color-adjust: exact;
    }
    body {
      font-family: Calibri, 'Segoe UI', Arial, sans-serif;
      font-size: 11pt;
      line-height: normal;
      color: #000;
    }
    h1, h2, h3, h4, h5, h6 { margin: 0; padding: 0.5em 0; font-size: inherit; font-weight: bold; }
    p { margin: 0; padding: 0; }
    
    .document-content { 
      padding: 0; 
      background: white; 
      width: 100%; 
    }
    
    /* FORCE relative positioning so Word content doesn't escape our margins */
    .libre-content, .libre-content * { 
      position: relative !important; 
      top: auto !important;
      left: auto !important;
      margin-top: auto;
    }
    
    .libre-content { padding-top: 5px; }
    .libre-content table { border-collapse: collapse; margin: 10pt 0; page-break-inside: auto; }
    .libre-content tr { page-break-inside: avoid; page-break-after: auto; }
    .libre-content td { padding: 4px; vertical-align: top; }
    .libre-content img { max-width: 100%; height: auto; display: block; }
  </style>
</head>
<body>
  <div class="document-content">
    ${body}
  </div>
</body>
</html>`;
  }
  formatDate(date) {
    if (!date) return "-";
    const dateObj = typeof date === "string" ? new Date(date) : date;
    if (isNaN(dateObj.getTime())) return "-";
    return dateObj.toLocaleDateString("en-GB");
  }
  getHeaderTemplate(document) {
    const deptName = document.creatorDepartmentName || "MR";
    const locationValue = document.location || "Unit 1";
    const revNo = document.revisionNo !== void 0 ? String(document.revisionNo).padStart(2, "0") : "00";
    const dateOfIssue = this.formatDate(document.dateOfIssue);
    const dateOfRev = this.formatDate(document.dateOfRev || (document.revisionNo > 0 ? document.dateOfIssue : null));
    const dueDate = this.formatDate(document.reviewDueDate);
    return `
      <style>
        #header { padding: 0 !important; margin: 0 !important; }
        .header-container { 
          margin: 0 !important;
          margin-left: 1.3cm !important;
          margin-right: 1cm !important;
          width: calc(100% - 2.3cm) !important;
          padding: 1cm 0 0.2cm 0 !important;
          font-family: 'Segoe UI', Calibri, Arial, sans-serif !important; 
          box-sizing: border-box;
          -webkit-print-color-adjust: exact;
        }
        .header-table { 
          width: 100%; 
          border-collapse: collapse; 
          border: 1.2pt solid #000; 
          table-layout: fixed; 
        }
        .header-table td { 
          border: 0.7pt solid #000; 
          padding: 3px 5px; 
          font-size: 8.5pt; 
          line-height: 1.35; 
          color: #000; 
          vertical-align: top; 
          word-wrap: break-word;
        }
        .company-name { 
          text-align: center; 
          font-weight: bold; 
          font-size: 10.5pt; 
          text-transform: uppercase; 
          border-bottom: 1.2pt solid #000 !important; 
          padding: 5px !important; 
          vertical-align: middle !important;
        }
        .label { font-weight: bold; }
      </style>
      <div class="header-container">
        <table class="header-table">
          <tr><td colspan="5" class="company-name">NEELIKON FOOD DYES AND CHEMICALS LIMITED</td></tr>
          <tr>
            <td style="width: 18.5%;"><span class="label">Location:</span> ${locationValue}</td>
            <td style="width: 19%;">
              <span class="label">Date of Issue:</span><br>
              <span>${dateOfIssue}</span>
            </td>
            <td style="width: 9.5%; white-space: nowrap;"><span class="label">Rev. No.:</span> ${revNo}</td>
            <td style="width: 38%;">
              <div style="white-space: nowrap;"><span class="label">Date of Rev.:</span> ${dateOfRev}</div>
              <div style="white-space: nowrap;"><span class="label">Due Date:</span> ${dueDate}</div>
            </td>
            <td style="width: 15%; text-align: center;"><span class="label">Page</span> <span class="pageNumber"></span> of <span class="totalPages"></span></td>
          </tr>
          <tr>
            <td style="width: 18.5%;"><span class="label">Dept.:</span> ${deptName}</td>
            <td colspan="3" style="width: 66.5%;"><span class="label">Title :</span> ${document.docName}</td>
            <td style="width: 15%;">
              <span class="label">Doc. No.:</span><br>
              <span>${document.docNumber}</span>
            </td>
          </tr>
        </table>
      </div>`;
  }
  getFooterTemplate(document, controlCopyInfo) {
    const preparer = document.preparerName || "Unknown";
    const approver = document.approverName || "Pending";
    const issuer = document.issuerName || "Pending";
    const status = (document.status || "PENDING").toUpperCase();
    let statusContent = `<span class="label">Status:</span> ${status}`;
    if (controlCopyInfo) {
      statusContent = `<span class="label">Controlled Copy</span><br><span style="font-size: 7pt;">(Printed by ${controlCopyInfo.userFullName})</span>`;
    }
    return `
      <style>
        #footer { padding: 0 !important; margin: 0 !important; }
        .footer-container { 
          margin: 0 !important;
          margin-left: 1.3cm !important;
          margin-right: 1cm !important;
          width: calc(100% - 2.3cm) !important;
          padding: 0.2cm 0 0.3cm 0 !important;
          font-family: 'Segoe UI', Arial, sans-serif !important; 
          box-sizing: border-box;
          font-size: 8.5pt;
          -webkit-print-color-adjust: exact;
        }
        .footer-table { width: 100%; border-collapse: collapse; border: 2px solid #000; table-layout: fixed; }
        .footer-table td { padding: 5px 10px; border: 1px solid #000; vertical-align: top; color: #000; }
        .label { font-weight: bold; }
      </style>
      <div class="footer-container">
        <table class="footer-table">
          <tr>
            <td style="width: 20%;"><span class="label">Prepared By:</span> ${preparer}</td>
            <td style="width: 20%;"><span class="label">Approved By:</span> ${approver}</td>
            <td style="width: 20%;"><span class="label">Issued By:</span> ${issuer}</td>
            <td style="width: 40%; text-align: center; vertical-align: middle;">${statusContent}</td>
          </tr>
        </table>
      </div>`;
  }
  async saveUploadedFile(fileBuffer, originalName, documentId) {
    await this.ensureDirectories();
    const fileName = `${documentId}_${Date.now()}_${originalName}`;
    const filePath = path.join(this.uploadsDir, fileName);
    await fs2.writeFile(filePath, fileBuffer);
    return `uploads/${fileName}`;
  }
  async extractHeaderFooterFromWord(buffer) {
    try {
      const zip = new AdmZip(buffer);
      const entries = zip.getEntries();
      let headerInfo = "";
      let footerInfo = "";
      for (const entry of entries) {
        if (entry.entryName.startsWith("word/header")) {
          const content = zip.readAsText(entry.entryName);
          const text = content.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
          if (text) headerInfo += (headerInfo ? " " : "") + text;
        } else if (entry.entryName.startsWith("word/footer")) {
          const content = zip.readAsText(entry.entryName);
          const text = content.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
          if (text) footerInfo += (footerInfo ? " " : "") + text;
        }
      }
      return {
        headerInfo: headerInfo.slice(0, 1e3),
        // Cap length for database storage
        footerInfo: footerInfo.slice(0, 1e3)
      };
    } catch (error) {
      console.error("Error extracting header/footer from Word:", error);
      return { headerInfo: "", footerInfo: "" };
    }
  }
};
var pdfService = new PDFService();

// server/routes.ts
import puppeteer2 from "puppeteer";
import { exec as execCallback } from "child_process";
import { promisify as promisify2 } from "util";
import { fileURLToPath as fileURLToPath2 } from "url";
import AdmZip2 from "adm-zip";
var __filename2 = fileURLToPath2(import.meta.url);
var __dirname2 = path2.dirname(__filename2);
var execAsync2 = promisify2(execCallback);
async function getCachedOrGeneratePdf(cacheKey, fullWordPath, enrichedDocument, controlCopyInfo) {
  console.log(`[PDF] Generating fresh PDF for key: ${cacheKey}...`);
  const pdfPath = await pdfService.convertWordToPDF(fullWordPath, enrichedDocument, controlCopyInfo);
  return pdfPath;
}
async function registerRoutes(app2) {
  const debugLog2 = (msg) => {
    const logPath = "c:\\inetpub\\wwwroot\\dms\\debug.log";
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    try {
      fs3.appendFileSync(logPath, `[${timestamp}] ${msg}
`);
    } catch (e) {
      console.error("Failed to write to debug log", e);
    }
  };
  app2.get("/api/version", (_req, res) => {
    res.json({ version: "1.0.6", timestamp: (/* @__PURE__ */ new Date()).toISOString() });
  });
  debugLog2("--- SERVER RESTARTED - ROUTES REGISTERED v1.0.6 ---");
  const upload = multer({ storage: multer.memoryStorage() });
  app2.post("/api/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      res.json({
        id: user.id,
        username: user.username,
        role: user.role,
        fullName: user.fullName,
        location: user.location,
        departmentId: user.departmentId || null,
        departmentName: user.departmentName || null,
        masterCopyAccess: user.masterCopyAccess || false
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json({
        id: user.id,
        username: user.username,
        role: user.role,
        fullName: user.fullName,
        location: user.location,
        departmentId: user.departmentId || null,
        departmentName: user.departmentName || null,
        masterCopyAccess: user.masterCopyAccess || false
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents", async (req, res) => {
    try {
      const { status, userId, recipientId, departmentId } = req.query;
      let documents;
      if (departmentId && status) {
        documents = await storage.getDocumentsByDepartment(departmentId, status, status === "issued");
      } else if (recipientId && status === "issued") {
        const user = await storage.getUser(recipientId);
        if (user?.departmentId) {
          documents = await storage.getDocumentsByDepartment(user.departmentId, "issued", true);
        } else {
          documents = await storage.getDocumentsByStatus("issued", true);
        }
      } else if (status) {
        documents = await storage.getDocumentsByStatus(status, status === "issued");
      } else if (userId) {
        documents = await storage.getDocumentsByUser(userId);
      } else {
        return res.status(400).json({ message: "Status, userId, or recipientId query parameter is required" });
      }
      const documentsWithDetails = await Promise.all(
        documents.map(async (doc) => {
          const preparer = await storage.getUser(doc.preparedBy);
          const approver = doc.approvedBy ? await storage.getUser(doc.approvedBy) : null;
          const issuer = doc.issuedBy ? await storage.getUser(doc.issuedBy) : null;
          let depts = await storage.getDocumentDepartments(doc.id);
          if (depts.length === 0 && preparer?.departmentId && preparer?.departmentName) {
            depts = [{
              id: preparer.departmentId,
              name: preparer.departmentName,
              code: preparer.departmentCode || "",
              category: null,
              categoryName: null,
              createdAt: /* @__PURE__ */ new Date()
            }];
          }
          return {
            ...doc,
            creatorDepartmentId: doc.creatorData && doc.creatorData.departmentId ? doc.creatorData.departmentId : preparer?.departmentId || null,
            creatorDepartmentCode: doc.creatorData && doc.creatorData.departmentCode ? doc.creatorData.departmentCode : preparer?.departmentCode || null,
            creatorDepartmentName: doc.creatorData && doc.creatorData.departmentName ? doc.creatorData.departmentName : preparer?.departmentName || null,
            preparerName: preparer?.fullName || "Unknown",
            approverName: approver?.fullName || null,
            issuerName: issuer?.fullName || null,
            departments: depts
          };
        })
      );
      res.json(documentsWithDetails);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/settings/:key", async (req, res) => {
    try {
      const setting = await storage.getSetting(req.params.key);
      if (!setting) {
        return res.json({ settingValue: "false" });
      }
      res.json(setting);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.put("/api/settings/:key", async (req, res) => {
    try {
      const { value } = req.body;
      const setting = await storage.updateSetting(req.params.key, value);
      res.json(setting);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents/due-for-review", async (req, res) => {
    try {
      const { daysAhead = "30" } = req.query;
      const daysAheadInt = parseInt(daysAhead, 10);
      if (isNaN(daysAheadInt) || daysAheadInt < 0) {
        return res.status(400).json({ message: "Invalid daysAhead parameter" });
      }
      const now = /* @__PURE__ */ new Date();
      const futureDate = /* @__PURE__ */ new Date();
      futureDate.setDate(futureDate.getDate() + daysAheadInt);
      const issuedDocs = await storage.getDocumentsByStatus("issued", true);
      const dueForReview = issuedDocs.filter((doc) => {
        if (!doc.reviewDueDate) return false;
        const dueDate = new Date(doc.reviewDueDate);
        return dueDate <= futureDate;
      });
      const documentsWithDetails = await Promise.all(
        dueForReview.map(async (doc) => {
          const preparer = await storage.getUser(doc.preparedBy);
          const depts = await storage.getDocumentDepartments(doc.id);
          const daysUntilDue = Math.ceil((new Date(doc.reviewDueDate).getTime() - now.getTime()) / (1e3 * 60 * 60 * 24));
          return {
            ...doc,
            creatorDepartmentId: doc.creatorData && doc.creatorData.departmentId ? doc.creatorData.departmentId : preparer?.departmentId || null,
            preparerName: preparer?.fullName || "Unknown",
            departments: depts,
            daysUntilDue,
            dateOfRev: doc.dateOfRev,
            dateOfIssue: doc.dateOfIssue
          };
        })
      );
      documentsWithDetails.sort((a, b) => a.daysUntilDue - b.daysUntilDue);
      res.json(documentsWithDetails);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents/department/:id", async (req, res) => {
    try {
      const { status } = req.query;
      const documents = await storage.getDocumentsByDepartment(req.params.id, status, status === "issued");
      const documentsWithDetails = await Promise.all(
        documents.map(async (doc) => {
          const preparer = await storage.getUser(doc.preparedBy);
          const approver = doc.approvedBy ? await storage.getUser(doc.approvedBy) : null;
          const issuer = doc.issuedBy ? await storage.getUser(doc.issuedBy) : null;
          let depts = await storage.getDocumentDepartments(doc.id);
          if (depts.length === 0 && preparer?.departmentId && preparer?.departmentName) {
            depts = [{ id: preparer.departmentId, name: preparer.departmentName, code: preparer.departmentCode || "", category: null, categoryName: null, createdAt: /* @__PURE__ */ new Date() }];
          }
          return {
            ...doc,
            creatorDepartmentId: doc.creatorData && doc.creatorData.departmentId ? doc.creatorData.departmentId : preparer?.departmentId || null,
            creatorDepartmentCode: doc.creatorData && doc.creatorData.departmentCode ? doc.creatorData.departmentCode : preparer?.departmentCode || null,
            creatorDepartmentName: doc.creatorData && doc.creatorData.departmentName ? doc.creatorData.departmentName : preparer?.departmentName || null,
            preparerName: preparer?.fullName || "Unknown",
            approverName: approver?.fullName || null,
            issuerName: issuer?.fullName || null,
            departments: depts
          };
        })
      );
      res.json(documentsWithDetails);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/next-revision-series", async (req, res) => {
    try {
      const { docNumber, location } = req.query;
      const nextRevisionNo = await storage.getGlobalNextRevisionNo(docNumber, location);
      res.json({ nextRevisionNo });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents/next-revision/:docNumber?", async (req, res) => {
    try {
      const docNumber = req.params.docNumber ? decodeURIComponent(decodeURIComponent(req.params.docNumber)) : void 0;
      const location = req.query.location;
      const nextRevisionNo = await storage.getGlobalNextRevisionNo(docNumber, location);
      res.json({ nextRevisionNo });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/revision-number", async (req, res) => {
    try {
      const { docNumber, location } = req.body;
      const nextRevisionNo = await storage.getGlobalNextRevisionNo(docNumber, location);
      res.json({ nextRevisionNo });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/documents/check-duplicate", async (req, res) => {
    try {
      const { docNumber, location, excludeDocId } = req.body;
      if (!docNumber || typeof docNumber !== "string" || docNumber.trim().length === 0) {
        return res.json({ isDuplicate: false });
      }
      const trimmedDocNum = docNumber.trim();
      const existingDocs = await storage.getDocumentsByDocNumber(trimmedDocNum, location);
      const conflict = existingDocs.find((d) => {
        if (excludeDocId && d.id === excludeDocId) return false;
        const st = (d.status || "").toLowerCase().trim();
        return ["pending", "approved", "issued", "declined"].includes(st);
      });
      if (conflict) {
        const overlap = getOverlappingUnits(location, conflict.location);
        return res.json({
          isDuplicate: true,
          conflict: {
            id: conflict.id,
            docName: conflict.docName,
            docNumber: conflict.docNumber,
            location: conflict.location || "All",
            revisionNo: conflict.revisionNo,
            status: conflict.status
          },
          overlappingUnits: overlap,
          message: `Document number "${trimmedDocNum}" already exists in location "${conflict.location || "All"}" ("${conflict.docName}", Rev ${conflict.revisionNo}, Status: ${conflict.status.toUpperCase()}). In the same location (${overlap.join(", ")}), duplicate document numbers cannot be created.`
        });
      }
      return res.json({ isDuplicate: false });
    } catch (error) {
      console.error("[Check Duplicate] Error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents/:id", async (req, res) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      const preparer = await storage.getUser(document.preparedBy);
      const approver = document.approvedBy ? await storage.getUser(document.approvedBy) : null;
      const issuer = document.issuedBy ? await storage.getUser(document.issuedBy) : null;
      let depts = await storage.getDocumentDepartments(document.id);
      if (depts.length === 0 && preparer?.departmentId && preparer?.departmentName) {
        depts = [{ id: preparer.departmentId, name: preparer.departmentName, code: preparer.departmentCode || "", category: null, categoryName: null, createdAt: /* @__PURE__ */ new Date() }];
      }
      const previousVersion = document.previousVersionId ? await storage.getDocument(document.previousVersionId) : null;
      res.json({
        ...document,
        creatorDepartmentId: document.creatorData && document.creatorData.departmentId ? document.creatorData.departmentId : preparer?.departmentId || null,
        preparerName: preparer?.fullName || "Unknown",
        approverName: approver?.fullName || null,
        issuerName: issuer?.fullName || null,
        departments: depts,
        previousVersion
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/documents", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "Word document file is required" });
      }
      const allowedMimeTypes = [
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "application/msword"
      ];
      if (!allowedMimeTypes.includes(req.file.mimetype)) {
        return res.status(400).json({ message: "Only Word documents (.doc, .docx) are allowed" });
      }
      const maxSize = 10 * 1024 * 1024;
      if (req.file.size > maxSize) {
        return res.status(400).json({ message: "File size must be less than 10MB" });
      }
      const extracted = await pdfService.extractHeaderFooterFromWord(req.file.buffer);
      const duePeriodYears = req.body.duePeriodYears ? parseInt(req.body.duePeriodYears, 10) : 3;
      const dateOfIssue = req.body.dateOfIssue ? new Date(req.body.dateOfIssue) : /* @__PURE__ */ new Date();
      const dateOfRev = req.body.dateOfRevision && req.body.dateOfRevision !== "" ? new Date(req.body.dateOfRevision) : req.body.dateOfRev ? new Date(req.body.dateOfRev) : null;
      let reviewBaseDate;
      let reviewDueDate;
      const originalDateOfIssue = req.body.originalDateOfIssue ? new Date(req.body.originalDateOfIssue) : dateOfIssue;
      const creator = await storage.getUser(req.body.preparedBy);
      const creatorData = creator ? {
        id: creator.id,
        username: creator.username,
        fullName: creator.fullName,
        role: creator.role,
        departmentId: creator.departmentId || null,
        departmentName: creator.departmentName || null
      } : null;
      if (req.body.docNumber) {
        const docNumTrimmed = req.body.docNumber.trim();
        const existingVersions = await storage.getDocumentsByDocNumber(docNumTrimmed, req.body.location);
        if (!req.body.previousVersionId) {
          const activeDuplicate = existingVersions.find((d) => {
            const st = (d.status || "").toLowerCase().trim();
            return ["pending", "approved", "issued", "declined"].includes(st);
          });
          if (activeDuplicate) {
            const overlap = getOverlappingUnits(req.body.location, activeDuplicate.location);
            return res.status(400).json({
              message: `Document number "${docNumTrimmed}" already exists in location "${activeDuplicate.location || "All"}" ("${activeDuplicate.docName}", Rev ${activeDuplicate.revisionNo}, Status: ${activeDuplicate.status.toUpperCase()}). Duplicate document numbers cannot be created in the same location (${overlap.join(", ")}). If you want to create a new revision, use "Revise Document".`
            });
          }
        } else {
          const inProgress = existingVersions.find(
            (v) => v.id !== req.body.previousVersionId && ["pending", "approved", "declined"].includes((v.status || "").toLowerCase().trim())
          );
          if (inProgress) {
            return res.status(400).json({
              message: `A revision for this document (Revision ${inProgress.revisionNo}) is already in state "${inProgress.status}". Please edit or resubmit that version instead of starting a new one.`
            });
          }
        }
      }
      const manualRevSetting = await storage.getSetting("enable_manual_revision");
      const isManualRevEnabled = manualRevSetting?.settingValue === "true";
      let nextRevisionNo;
      const rawRevNo = req.body.revisionNo !== void 0 ? req.body.revisionNo : req.body.revisionNumber;
      const parsedRevNo = parseInt(rawRevNo, 10);
      if (req.body.migrationMode && !isNaN(parsedRevNo)) {
        nextRevisionNo = parsedRevNo;
      } else if (isManualRevEnabled && !isNaN(parsedRevNo)) {
        nextRevisionNo = parsedRevNo;
      } else {
        nextRevisionNo = await storage.getGlobalNextRevisionNo(req.body.docNumber, req.body.location);
      }
      reviewBaseDate = dateOfRev ? dateOfRev : dateOfIssue;
      reviewDueDate = new Date(reviewBaseDate);
      reviewDueDate.setFullYear(reviewDueDate.getFullYear() + duePeriodYears);
      reviewDueDate.setDate(reviewDueDate.getDate() - 1);
      const issueNo = null;
      let inheritedData = {};
      if (req.body.previousVersionId) {
        const previousDoc = await storage.getDocument(req.body.previousVersionId);
        if (previousDoc) {
          inheritedData = {
            duePeriodYears: req.body.duePeriodYears || previousDoc.duePeriodYears,
            location: req.body.location || previousDoc.location,
            originalDateOfIssue: previousDoc.originalDateOfIssue || previousDoc.dateOfIssue,
            // Use provided dateOfRev or default to current date
            dateOfRev: dateOfRev || /* @__PURE__ */ new Date(),
            reasonForRevision: req.body.reasonForRevision || `Revision of ${previousDoc.docName} (v${previousDoc.revisionNo})`
          };
        }
      }
      const documentData = {
        ...req.body,
        ...inheritedData,
        revisionNo: nextRevisionNo,
        duePeriodYears: inheritedData.duePeriodYears || duePeriodYears,
        reasonForRevision: inheritedData.reasonForRevision || req.body.reasonForRevision || void 0,
        issueNo,
        dateOfIssue,
        reviewDueDate,
        dateOfRev: dateOfRev || inheritedData.dateOfRev || null,
        originalDateOfIssue: inheritedData.originalDateOfIssue || originalDateOfIssue,
        headerInfo: req.body.headerInfo && req.body.headerInfo !== "undefined" ? req.body.headerInfo : extracted.headerInfo || "",
        footerInfo: req.body.footerInfo && req.body.footerInfo !== "undefined" ? req.body.footerInfo : extracted.footerInfo || "",
        preparerName: req.body.preparerName || creator?.fullName || "",
        location: inheritedData.location || req.body.location || creator?.location || null,
        previousVersionId: req.body.previousVersionId || null,
        // Store the link to previous version
        creatorData
      };
      const document = await storage.createDocument(documentData);
      let departmentsToAssign = [];
      if (req.body.previousVersionId) {
        const previousDepts = await storage.getDocumentDepartments(req.body.previousVersionId);
        departmentsToAssign = previousDepts.map((d) => d.id);
      }
      const explicitDeptId = req.body.departmentId || creator?.departmentId;
      if (explicitDeptId && explicitDeptId !== "undefined") {
        departmentsToAssign = [explicitDeptId];
      }
      if (departmentsToAssign.length > 0) {
        await storage.assignDocumentToDepartments(document.id, departmentsToAssign);
      }
      const filePath = await pdfService.saveUploadedFile(
        req.file.buffer,
        req.file.originalname,
        document.id
      );
      await storage.updateDocument(document.id, { wordFilePath: filePath });
      const approvers = await storage.getUsersByRole("approver");
      for (const approver of approvers) {
        await storage.createNotification({
          userId: approver.id,
          documentId: document.id,
          message: `New document "${document.docName}" (${document.docNumber}) is ready for your approval`,
          type: "new_document"
        });
      }
      res.status(201).json({ ...document, wordFilePath: filePath });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.patch("/api/documents/:id", upload.single("file"), async (req, res) => {
    return handleDocumentUpdate(req, res);
  });
  app2.put("/api/documents/:id", upload.single("file"), async (req, res) => {
    return handleDocumentUpdate(req, res);
  });
  const handleDocumentUpdate = async (req, res) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      const currentStatus = (document.status || "").trim().toLowerCase();
      console.log(`[Update] Document ID: ${req.params.id}. Current Status: ${document.status} (normalized: ${currentStatus})`);
      console.log("[Update] Received fields for update:", Object.keys(req.body));
      if (currentStatus === "approved" || currentStatus === "issued") {
        return res.status(400).json({ message: "Approved or issued documents cannot be edited. Use 'Revise' to create a new version." });
      }
      let {
        docName,
        docNumber,
        dateOfIssue,
        revisionNumber,
        revisionNo,
        duePeriodYears,
        reasonForRevision,
        location,
        preparerName,
        dateOfRev,
        reviewDueDate,
        departments
      } = req.body;
      if (departments && typeof departments === "string") {
        try {
          departments = JSON.parse(departments);
        } catch (e) {
          console.warn("Could not parse departments JSON, using as-is");
        }
      }
      const updateData = {
        updatedAt: /* @__PURE__ */ new Date()
      };
      const checkDocNumber = (docNumber !== void 0 ? docNumber : document.docNumber)?.trim();
      const checkLocation = location !== void 0 ? location : document.location;
      if (checkDocNumber && (docNumber !== void 0 || location !== void 0)) {
        const existingVersions = await storage.getDocumentsByDocNumber(checkDocNumber, checkLocation);
        const conflict = existingVersions.find(
          (d) => d.id !== req.params.id && d.id !== document.previousVersionId && d.previousVersionId !== req.params.id && ["pending", "approved", "issued", "declined"].includes((d.status || "").toLowerCase().trim())
        );
        if (conflict) {
          const overlap = getOverlappingUnits(checkLocation, conflict.location);
          return res.status(400).json({
            message: `Document number "${checkDocNumber}" already exists in location "${conflict.location || "All"}" ("${conflict.docName}", Rev ${conflict.revisionNo}, Status: ${conflict.status.toUpperCase()}). Duplicate document numbers cannot be created in the same location (${overlap.join(", ")}).`
          });
        }
      }
      debugLog2(`[Update] Status check: current=${currentStatus}, original=${document.status}`);
      if (currentStatus === "declined") {
        debugLog2(`[Update] Resubmitting declined document ${req.params.id}. Resetting to pending.`);
        updateData.status = "pending";
        updateData.declineRemarks = null;
        updateData.approvalRemarks = null;
        updateData.approvedBy = null;
        updateData.issuedBy = null;
        updateData.approvedAt = null;
        updateData.issuedAt = null;
      }
      if (docName !== void 0) updateData.docName = docName;
      if (docNumber !== void 0) updateData.docNumber = docNumber;
      if (dateOfIssue !== void 0 && dateOfIssue !== "") {
        const d = new Date(dateOfIssue);
        if (!isNaN(d.getTime())) {
          updateData.dateOfIssue = d;
        }
      }
      const rev = revisionNo !== void 0 ? revisionNo : revisionNumber;
      if (rev !== void 0) {
        const parsedRev = parseInt(rev, 10);
        if (!isNaN(parsedRev)) {
          updateData.revisionNo = parsedRev;
        }
      }
      if (duePeriodYears !== void 0) {
        const parsedYears = parseInt(duePeriodYears, 10);
        if (!isNaN(parsedYears)) {
          updateData.duePeriodYears = parsedYears;
        }
      }
      if (reasonForRevision !== void 0) updateData.reasonForRevision = reasonForRevision;
      if (location !== void 0) updateData.location = location;
      if (preparerName !== void 0) updateData.preparerName = preparerName;
      if (dateOfRev !== void 0 && dateOfRev !== "") {
        const d = new Date(dateOfRev);
        if (!isNaN(d.getTime())) {
          updateData.dateOfRev = d;
        } else {
          updateData.dateOfRev = null;
        }
      } else if (dateOfRev === "") {
        updateData.dateOfRev = null;
      }
      if (reviewDueDate !== void 0 && reviewDueDate !== "") {
        const d = new Date(reviewDueDate);
        if (!isNaN(d.getTime())) {
          updateData.reviewDueDate = d;
        } else {
          updateData.reviewDueDate = null;
        }
      } else if (reviewDueDate === "") {
        updateData.reviewDueDate = null;
      }
      if (req.file) {
        const filePath = await pdfService.saveUploadedFile(
          req.file.buffer,
          req.file.originalname,
          document.id
        );
        updateData.wordFilePath = filePath;
      }
      if (updateData.reviewDueDate === void 0) {
        const newDateOfRev = updateData.dateOfRev !== void 0 ? updateData.dateOfRev : document.dateOfRev;
        const newDateOfIssue = updateData.dateOfIssue || document.dateOfIssue;
        const newDuePeriod = updateData.duePeriodYears !== void 0 ? updateData.duePeriodYears : document.duePeriodYears;
        const currentRevNo = updateData.revisionNo !== void 0 ? updateData.revisionNo : document.revisionNo || 0;
        const reviewBaseDate = newDateOfRev ? newDateOfRev : newDateOfIssue;
        if (reviewBaseDate && newDuePeriod) {
          const calculatedReviewDueDate = new Date(reviewBaseDate);
          calculatedReviewDueDate.setFullYear(calculatedReviewDueDate.getFullYear() + newDuePeriod);
          calculatedReviewDueDate.setDate(calculatedReviewDueDate.getDate() - 1);
          updateData.reviewDueDate = calculatedReviewDueDate;
        }
      }
      debugLog2(`[Update] Final updateData keys for ${req.params.id}: ${Object.keys(updateData).join(", ")}`);
      debugLog2(`[Update] Final updateData values: ${JSON.stringify(updateData)}`);
      const updatedDoc = await storage.updateDocument(req.params.id, updateData);
      if (departments && Array.isArray(departments)) {
        await storage.assignDocumentToDepartments(req.params.id, departments);
      }
      if (document.status === "declined") {
        const approvers = await storage.getUsersByRole("approver");
        for (const approver of approvers) {
          await storage.createNotification({
            userId: approver.id,
            documentId: document.id,
            message: `Document "${document.docName}" (${document.docNumber}) has been resubmitted after decline`,
            type: "new_document"
          });
        }
      }
      res.json(updatedDoc);
    } catch (error) {
      console.error("Error updating document:", error);
      res.status(500).json({ message: error.message });
    }
  };
  app2.delete("/api/documents/:id", async (req, res) => {
    try {
      await storage.deleteDocument(req.params.id);
      res.json({ success: true, message: "Document deleted successfully" });
    } catch (error) {
      if (error.message.includes("not found")) {
        res.status(404).json({ message: error.message });
      } else if (error.message.includes("Cannot delete")) {
        res.status(403).json({ message: error.message });
      } else {
        res.status(500).json({ message: error.message });
      }
    }
  });
  app2.post("/api/documents/:id/approve", async (req, res) => {
    try {
      const { approvalRemarks, approvedBy, approverName, departments, docNumber } = req.body;
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      const approver = await storage.getUser(approvedBy);
      const finalApproverName = approverName || approver?.fullName || "Unknown";
      const approverData = approver ? {
        id: approver.id,
        username: approver.username,
        fullName: approver.fullName,
        role: approver.role,
        departmentId: approver.departmentId || null,
        departmentName: approver.departmentName || null
      } : null;
      const updatedDoc = await storage.updateDocument(req.params.id, {
        status: "approved",
        approvalRemarks,
        approvedBy,
        approverName: approver?.fullName || approverName,
        approvedAt: /* @__PURE__ */ new Date(),
        approverData,
        // Update docNumber if provided during approval
        ...docNumber && { docNumber }
      });
      if (departments && departments.length > 0) {
        await storage.assignDocumentToDepartments(req.params.id, departments);
      }
      const issuers = await storage.getUsersByRole("issuer");
      for (const issuer of issuers) {
        await storage.createNotification({
          userId: issuer.id,
          documentId: req.params.id,
          message: `Document "${document.docName}" (${document.docNumber}) has been approved by ${finalApproverName}. Remarks: "${approvalRemarks}"`,
          type: "approved_document"
        });
      }
      await storage.createNotification({
        userId: document.preparedBy,
        documentId: req.params.id,
        message: `Your document "${document.docName}" (${document.docNumber}) has been approved by ${finalApproverName}`,
        type: "document_status_update"
      });
      res.json(updatedDoc);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/documents/:id/decline", async (req, res) => {
    try {
      const { declineRemarks, declinedBy, declinerName } = req.body;
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      const updatedDoc = await storage.updateDocument(req.params.id, {
        status: "declined",
        declineRemarks,
        declinedBy: declinedBy || null,
        declinerName: declinerName || null,
        declinedAt: /* @__PURE__ */ new Date(),
        approvedBy: null,
        issuedBy: null
      });
      await storage.createNotification({
        userId: document.preparedBy,
        documentId: req.params.id,
        message: `Your document "${document.docName}" (${document.docNumber}) has been declined by issuer. Remarks: ${declineRemarks}. Please review and resubmit.`,
        type: "document_declined"
      });
      res.json(updatedDoc);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/documents/:id/issue", async (req, res) => {
    try {
      const { issuedBy, issuerName, remarks, departments: targetDepartments, docNumber } = req.body;
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      if (targetDepartments && Array.isArray(targetDepartments)) {
        await storage.assignDocumentToDepartments(req.params.id, targetDepartments);
      }
      const issuer = await storage.getUser(issuedBy);
      const issuerData = issuer ? {
        id: issuer.id,
        username: issuer.username,
        fullName: issuer.fullName,
        role: issuer.role,
        departmentId: issuer.departmentId || null,
        departmentName: issuer.departmentName || null
      } : null;
      const updatedDoc = await storage.updateDocument(req.params.id, {
        status: "issued",
        issuedBy,
        issuerName,
        issueRemarks: remarks,
        issuedAt: /* @__PURE__ */ new Date(),
        issuerData,
        docNumber: docNumber || void 0
      });
      const currentDocNumber = docNumber || document.docNumber;
      if (currentDocNumber) {
        try {
          await storage.obsoleteSupersededIssuedDocuments(currentDocNumber, document.location || void 0, req.params.id);
        } catch (supErr) {
          console.error("[Obsolete] Error marking previous versions as obsolete:", supErr);
        }
      }
      await storage.createNotification({
        userId: document.preparedBy,
        documentId: req.params.id,
        message: `Your document "${document.docName}" (${document.docNumber}) has been issued by ${issuerName}`,
        type: "document_issued"
      });
      if (document.approvedBy) {
        await storage.createNotification({
          userId: document.approvedBy,
          documentId: req.params.id,
          message: `Document "${document.docName}" (${document.docNumber}) has been issued`,
          type: "document_issued"
        });
      }
      const departments = await storage.getDocumentDepartments(req.params.id);
      for (const dept of departments) {
        await storage.createDocumentRecipient({
          documentId: req.params.id,
          departmentId: dept.id
        });
      }
      res.json(updatedDoc);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/notifications/:userId", async (req, res) => {
    try {
      const notifications = await storage.getUserNotifications(req.params.userId);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/notifications/:id/read", async (req, res) => {
    try {
      await storage.markNotificationAsRead(req.params.id);
      res.json({ message: "Notification marked as read" });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/departments/categorized", async (req, res) => {
    try {
      const departments = await storage.getDepartments();
      const categoryMap = {};
      for (const dept of departments) {
        const catId = dept.category || "uncategorized";
        const catName = dept.categoryName || "Uncategorized";
        if (!categoryMap[catId]) {
          categoryMap[catId] = { id: catId, name: catName, departments: [] };
        }
        categoryMap[catId].departments.push({ id: dept.id, name: dept.name });
      }
      const categories = Object.values(categoryMap);
      res.json({ categories });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/departments", async (req, res) => {
    try {
      const departments = await storage.getDepartments();
      res.json(departments);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/departments", async (req, res) => {
    try {
      const department = await storage.createDepartment(req.body);
      res.status(201).json(department);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/users", async (req, res) => {
    try {
      const user = await storage.createUser(req.body);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/users", async (req, res) => {
    try {
      const { role } = req.query;
      if (role) {
        const users = await storage.getUsersByRole(role);
        res.json(users);
      } else {
        res.status(400).json({ message: "Role query parameter is required" });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/users/:id", async (req, res) => {
    try {
      await storage.deleteUser(req.params.id);
      res.json({ success: true, message: "User deleted successfully" });
    } catch (error) {
      if (error.message.includes("not found")) {
        res.status(404).json({ message: error.message });
      } else {
        res.status(500).json({ message: error.message });
      }
    }
  });
  app2.put("/api/users/:id", async (req, res) => {
    try {
      const updatedUser = await storage.updateUser(req.params.id, req.body);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(updatedUser);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.delete("/api/departments/:id", async (req, res) => {
    try {
      await storage.deleteDepartment(req.params.id);
      res.json({ success: true, message: "Department deleted successfully" });
    } catch (error) {
      if (error.message.includes("not found")) {
        res.status(404).json({ message: error.message });
      } else {
        res.status(500).json({ message: error.message });
      }
    }
  });
  app2.get("/api/admin/users", async (req, res) => {
    try {
      const creators = await storage.getUsersByRole("creator");
      const approvers = await storage.getUsersByRole("approver");
      const issuers = await storage.getUsersByRole("issuer");
      const admins = await storage.getUsersByRole("admin");
      const recipients = await storage.getUsersByRole("recipient");
      const mapUser2 = (u) => ({
        id: u.id,
        username: u.username,
        fullName: u.fullName,
        role: u.role,
        departmentId: u.departmentId,
        departmentName: u.departmentName,
        location: u.location,
        masterCopyAccess: u.masterCopyAccess
      });
      res.json({
        creators: creators.map(mapUser2),
        approvers: approvers.map(mapUser2),
        issuers: issuers.map(mapUser2),
        admins: admins.map(mapUser2),
        recipients: recipients.map(mapUser2),
        total: creators.length + approvers.length + issuers.length + admins.length + recipients.length
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/admin/documents", async (req, res) => {
    try {
      const pending = await storage.getDocumentsByStatus("pending");
      const approved = await storage.getDocumentsByStatus("approved");
      const issued = await storage.getDocumentsByStatus("issued", true);
      const declined = await storage.getDocumentsByStatus("declined");
      const obsolete = await storage.getDocumentsByStatus("obsolete");
      const allDocs = [...pending, ...approved, ...issued, ...declined, ...obsolete];
      const revisionCounts = {};
      allDocs.forEach((doc) => {
        if (doc.docNumber) {
          const key = `${doc.docNumber.trim().toLowerCase()}_${(doc.location || "").trim().toLowerCase()}`;
          revisionCounts[key] = (revisionCounts[key] || 0) + 1;
        }
      });
      const documentsWithDetails = await Promise.all(
        allDocs.map(async (doc) => {
          const preparer = await storage.getUser(doc.preparedBy);
          const approver = doc.approvedBy ? await storage.getUser(doc.approvedBy) : null;
          const issuer = doc.issuedBy ? await storage.getUser(doc.issuedBy) : null;
          const key = doc.docNumber ? `${doc.docNumber.trim().toLowerCase()}_${(doc.location || "").trim().toLowerCase()}` : "";
          const revCount = revisionCounts[key] || 0;
          let depts = await storage.getDocumentDepartments(doc.id);
          if (depts.length === 0 && preparer?.departmentId && preparer?.departmentName) {
            depts = [{ id: preparer.departmentId, name: preparer.departmentName, code: preparer.departmentCode || "", category: null, categoryName: null, createdAt: /* @__PURE__ */ new Date() }];
          }
          return {
            ...doc,
            revisionCount: revCount,
            creatorDepartmentId: doc.creatorData && doc.creatorData.departmentId ? doc.creatorData.departmentId : preparer?.departmentId || null,
            preparerName: preparer?.fullName || "Unknown",
            approverName: approver?.fullName || null,
            issuerName: issuer?.fullName || null,
            departments: depts
          };
        })
      );
      res.json({
        documents: documentsWithDetails,
        stats: {
          total: allDocs.length,
          pending: pending.length,
          approved: approved.length,
          issued: issued.length,
          declined: declined.length,
          obsolete: obsolete.length
        }
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/admin/stats", async (req, res) => {
    try {
      const pending = await storage.getDocumentsByStatus("pending");
      const approved = await storage.getDocumentsByStatus("approved");
      const issued = await storage.getDocumentsByStatus("issued");
      const declined = await storage.getDocumentsByStatus("declined");
      const obsolete = await storage.getDocumentsByStatus("obsolete");
      const departments = await storage.getDepartments();
      const creators = await storage.getUsersByRole("creator");
      const approvers = await storage.getUsersByRole("approver");
      const issuers = await storage.getUsersByRole("issuer");
      const now = /* @__PURE__ */ new Date();
      const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1e3);
      const allDocs = [...pending, ...approved, ...issued, ...declined, ...obsolete];
      const recentDocs = allDocs.filter(
        (doc) => doc.createdAt && new Date(doc.createdAt) >= thirtyDaysAgo
      );
      const weeklyActivity = [];
      const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      for (let i = 6; i >= 0; i--) {
        const date = new Date(now.getTime() - i * 24 * 60 * 60 * 1e3);
        const dayDocs = allDocs.filter((doc) => {
          if (!doc.createdAt) return false;
          const docDate = new Date(doc.createdAt);
          return docDate.toDateString() === date.toDateString();
        });
        weeklyActivity.push({
          day: days[date.getDay()],
          documents: dayDocs.length
        });
      }
      res.json({
        documents: {
          total: allDocs.length,
          pending: pending.length,
          approved: approved.length,
          issued: issued.length,
          declined: declined.length,
          obsolete: allDocs.filter((d) => (d.status || "").toLowerCase() === "obsolete").length,
          recentCount: recentDocs.length
        },
        users: {
          creators: creators.length,
          approvers: approvers.length,
          issuers: issuers.length,
          total: creators.length + approvers.length + issuers.length
        },
        departments: {
          total: departments.length,
          list: departments
        },
        weeklyActivity,
        recentDocuments: allDocs.slice(0, 10).map((doc) => ({
          id: doc.id,
          docName: doc.docName,
          docNumber: doc.docNumber,
          status: doc.status,
          createdAt: doc.createdAt
        }))
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/documents/:id/upload", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      const filePath = await pdfService.saveUploadedFile(
        req.file.buffer,
        req.file.originalname,
        req.params.id
      );
      const updatedDoc = await storage.updateDocument(req.params.id, {
        wordFilePath: filePath
      });
      res.json({ message: "File uploaded successfully", document: updatedDoc });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents/:id/download", async (req, res) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      if (!document.wordFilePath) {
        return res.status(404).json({ message: "No Word file available for this document" });
      }
      if (document.status === "issued") {
        return res.status(403).json({
          message: "Issued documents (controlled copies) cannot be downloaded in Word format. Please use the Print Controlled Copy option in the PDF viewer."
        });
      }
      const fullPath = path2.join(pdfService.uploadsDir, path2.basename(document.wordFilePath));
      try {
        await fsPromises.access(fullPath);
        const fileName = path2.basename(fullPath);
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
        const fileBuffer = await fsPromises.readFile(fullPath);
        res.send(fileBuffer);
      } catch (err) {
        console.error("Download error:", err);
        return res.status(404).json({ message: "Word file not found on server" });
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents/:id/view-word", async (req, res) => {
    try {
      debugLog2(`[Word View] Requesting document ${req.params.id}`);
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        debugLog2(`[Word View] Document ${req.params.id} not found`);
        return res.status(404).json({ message: "Document not found" });
      }
      if (!document.wordFilePath) {
        debugLog2(`[Word View] No Word file path for document ${req.params.id}`);
        return res.status(404).json({ message: "No Word file available for this document" });
      }
      let fullPath;
      let wordBuffer;
      if (path2.isAbsolute(document.wordFilePath)) {
        fullPath = document.wordFilePath;
      } else {
        fullPath = path2.join(pdfService.uploadsDir, document.wordFilePath);
      }
      debugLog2(`[Word View] Primary path attempt: ${fullPath}`);
      try {
        await fsPromises.access(fullPath);
        wordBuffer = await fsPromises.readFile(fullPath);
        debugLog2(`[Word View] Successfully read file from primary path, size: ${wordBuffer.length} bytes`);
      } catch (err) {
        debugLog2(`[Word View] Primary path failed: ${err.message}`);
        const fallbackPath = path2.join(pdfService.uploadsDir, path2.basename(document.wordFilePath));
        debugLog2(`[Word View] Trying fallback path: ${fallbackPath}`);
        try {
          await fsPromises.access(fallbackPath);
          wordBuffer = await fsPromises.readFile(fallbackPath);
          fullPath = fallbackPath;
          debugLog2(`[Word View] Successfully read file from fallback path, size: ${wordBuffer.length} bytes`);
        } catch (fallbackErr) {
          debugLog2(`[Word View] Fallback path also failed: ${fallbackErr.message}`);
          try {
            const availableFiles = await fsPromises.readdir(pdfService.uploadsDir);
            debugLog2(`[Word View] Available files in uploads dir: ${availableFiles.join(", ")}`);
          } catch {
            debugLog2(`[Word View] Unable to read uploads directory`);
          }
          return res.status(404).json({ message: `Word file not found on server. Tried: ${fullPath}, ${fallbackPath}` });
        }
      }
      const magicNumber = wordBuffer.toString("hex", 0, 8);
      if (magicNumber.startsWith("d0cf11e0a1b11ae1")) {
        debugLog2(`[Word View] Legacy .doc file detected for document ${req.params.id}. Magic number: ${magicNumber}`);
        return res.status(400).json({ message: "This is a legacy Word (.doc) file. The system only supports modern .docx files for viewing. Please convert this file to .docx and re-upload." });
      }
      debugLog2(`[Word View] Processing .docx file for document ${req.params.id}.`);
      const mammoth2 = await import("mammoth");
      const result = await mammoth2.convertToHtml({
        buffer: wordBuffer
      }, {
        styleMap: [
          "p[style-name='Header'] => h1:fresh",
          "p[style-name='Heading 1'] => h2:fresh",
          "p[style-name='Heading 2'] => h3:fresh",
          "p[style-name='Heading 3'] => h4:fresh",
          "p[style-name='List Paragraph'] => p.list-paragraph:fresh",
          "p[style-name='Normal'] => p:fresh",
          "r[style-name='Strong'] => strong:fresh",
          "r[style-name='Emphasis'] => em:fresh",
          "table => table.document-table:fresh",
          "b => strong",
          "i => em",
          "u => span.underline"
        ],
        includeDefaultStyleMap: true,
        convertImage: mammoth2.images.imgElement(function(image) {
          return image.read("base64").then(function(imageBuffer) {
            return { src: "data:" + image.contentType + ";base64," + imageBuffer };
          });
        })
      });
      debugLog2(`[Word View] Mammoth conversion complete, HTML length: ${result.value.length} `);
      res.json({
        html: result.value,
        messages: result.messages,
        docName: document.docName,
        docNumber: document.docNumber,
        revisionNo: document.revisionNo
      });
    } catch (error) {
      debugLog2(`[Word View] Server error: ${error.message} `);
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/health/pdf", async (req, res) => {
    try {
      console.log("PDF health check requested");
      const browser = await puppeteer2.launch({
        headless: true,
        args: ["--no-sandbox", "--disable-setuid-sandbox"]
      });
      const page = await browser.newPage();
      await page.setContent("<html><body><h1>Test PDF</h1></body></html>");
      const pdfBuffer = await page.pdf({
        format: "A4",
        printBackground: true
      });
      await browser.close();
      res.json({
        status: "healthy",
        pdfService: "operational",
        puppeteer: "working",
        testPdfSize: pdfBuffer.length
      });
    } catch (error) {
      console.error("PDF health check failed:", error);
      res.status(500).json({
        status: "unhealthy",
        error: error.message,
        pdfService: "failed"
      });
    }
  });
  app2.get("/api/documents/:id/preview-pdf", async (req, res) => {
    try {
      console.log("PDF preview request for document:", req.params.id);
      const { userId } = req.query;
      if (!userId) {
        return res.status(400).json({ message: "userId query parameter is required" });
      }
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      if (user.role !== "issuer" && user.role !== "admin") {
        return res.status(403).json({ message: "Only issuers and admins can preview approved documents" });
      }
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      if (document.status !== "approved" && document.status !== "issued") {
        return res.status(403).json({ message: "Only approved or issued documents can be previewed" });
      }
      if (!document.wordFilePath) {
        return res.status(404).json({ message: "No Word file uploaded for this document" });
      }
      const fullWordPath = path2.join(pdfService.uploadsDir, path2.basename(document.wordFilePath));
      try {
        await fsPromises.access(fullWordPath);
      } catch (fileError) {
        console.error("Word file not found:", fullWordPath, fileError);
        return res.status(404).json({ message: "Word file not found on server" });
      }
      let pdfPath;
      try {
        const preparer = await storage.getUser(document.preparedBy);
        const approver = document.approvedBy ? await storage.getUser(document.approvedBy) : null;
        const issuer = document.issuedBy ? await storage.getUser(document.issuedBy) : null;
        const depts = await storage.getDocumentDepartments(document.id);
        const departmentNames = depts.map((d) => d.name);
        const enrichedDocument = {
          ...document,
          departments: depts,
          departmentNames,
          creatorDepartmentName: preparer?.departmentName || "MR",
          preparerName: preparer?.fullName || "Unknown",
          approverName: approver?.fullName || "Pending",
          issuerName: issuer?.fullName || "Pending",
          location: document.location || preparer?.location || ""
        };
        const previewCacheKey = `preview_${document.id}_rev${document.revisionNo}`;
        pdfPath = await getCachedOrGeneratePdf(previewCacheKey, fullWordPath, enrichedDocument);
      } catch (err) {
        console.error("PDF conversion error:", err);
        return res.status(500).json({ message: "Failed to convert Word to PDF. Please check the document file and try again." });
      }
      try {
        const pdfBuffer = await fsPromises.readFile(pdfPath);
        if (pdfBuffer.length === 0) {
          throw new Error("PDF file is empty");
        }
        const { download } = req.query;
        res.setHeader("Content-Type", "application/pdf");
        if (download === "true") {
          const fileName = `${document.docNumber}_${document.docName}_PREVIEW.pdf`.replace(/[/\\?%*:|"<>]/g, "-");
          res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
        } else {
          res.setHeader("Content-Disposition", 'inline; filename="document-preview.pdf"');
        }
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        res.setHeader("Content-Length", pdfBuffer.length.toString());
        res.send(pdfBuffer);
      } catch (err) {
        console.error("PDF file read error:", err);
        return res.status(500).json({ message: "PDF file not found or unreadable after conversion." });
      }
    } catch (error) {
      console.error("PDF preview endpoint error:", error);
      res.status(500).json({ message: error.message || "Internal server error" });
    }
  });
  app2.get("/api/documents/:id/pdf", async (req, res) => {
    try {
      console.log("PDF request for document:", req.params.id);
      const { userId, version } = req.query;
      if (!userId) {
        console.log("Missing userId parameter");
        return res.status(400).json({ message: "userId query parameter is required" });
      }
      const user = await storage.getUser(userId);
      if (!user) {
        console.log("User not found:", userId);
        return res.status(404).json({ message: "User not found" });
      }
      let document = await storage.getDocument(req.params.id);
      if (!document) {
        console.log("Document not found:", req.params.id);
        return res.status(404).json({ message: "Document not found" });
      }
      console.log("Found document:", document.docName, "Status:", document.status);
      const originalDocNumber = document.docNumber;
      const allIssuedDocs = await storage.getDocumentsByStatus("issued");
      const allVersions = allIssuedDocs.filter((d) => d.docNumber === originalDocNumber);
      if (allVersions.length === 0) {
        console.log("No issued versions found for document:", originalDocNumber);
        return res.status(404).json({ message: "No issued versions found for this document" });
      }
      const latestVersion = allVersions.reduce((latest, current) => {
        return current.revisionNo > latest.revisionNo ? current : latest;
      }, allVersions[0]);
      if (version !== void 0) {
        const requestedVersion = parseInt(version, 10);
        if (isNaN(requestedVersion)) {
          return res.status(400).json({ message: "Invalid version parameter" });
        }
        const userRole = user.role?.toLowerCase() || "";
        if (!user.masterCopyAccess && !["approver", "creator", "issuer", "admin"].includes(userRole)) {
          return res.status(403).json({ message: "Access denied. Only master copy users can access specific versions." });
        }
        const requestedDoc = allVersions.find((d) => d.revisionNo === requestedVersion);
        if (!requestedDoc) {
          return res.status(404).json({ message: `Version ${requestedVersion} not found` });
        }
        document = await storage.getDocument(requestedDoc.id) || requestedDoc;
      } else if (!user.masterCopyAccess && !["approver", "creator", "issuer", "admin"].includes(user.role?.toLowerCase() || "") && document.id !== latestVersion.id) {
        return res.status(403).json({ message: "Access denied. Only the latest version can be accessed. Please contact administrator for previous versions." });
      }
      if (document.status !== "issued" && !(document.status === "approved" && user.role === "issuer")) {
        console.log("Document access denied, status:", document.status, "user role:", user.role);
        return res.status(403).json({ message: "Only issued documents (or approved documents for issuers) can be viewed as PDF" });
      }
      console.log("PDF access granted for issued document:", document.docName, "to user:", user.fullName);
      if (!document.wordFilePath) {
        console.log("No Word file path for document:", document.id);
        return res.status(404).json({ message: "No Word file uploaded for this document" });
      }
      const fullWordPath = path2.join(pdfService.uploadsDir, path2.basename(document.wordFilePath));
      try {
        await fsPromises.access(fullWordPath);
        console.log("Word file exists:", fullWordPath);
      } catch (fileError) {
        console.error("Word file not found:", fullWordPath, fileError);
        return res.status(404).json({ message: "Word file not found on server" });
      }
      let pdfPath;
      try {
        console.log("Creating control copy...");
        const controlCopy = await storage.createControlCopy({
          documentId: document.id,
          userId,
          actionType: "view"
        });
        const controlCopyInfo = {
          userId: user.id,
          userFullName: user.fullName,
          controlCopyNumber: controlCopy.copyNumber,
          date: (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB")
        };
        const preparer = await storage.getUser(document.preparedBy);
        const approver = document.approvedBy ? await storage.getUser(document.approvedBy) : null;
        const issuer = document.issuedBy ? await storage.getUser(document.issuedBy) : null;
        const depts = await storage.getDocumentDepartments(document.id);
        const departmentNames = depts.map((d) => d.name);
        const enrichedDocument = {
          ...document,
          departments: depts,
          departmentNames,
          creatorDepartmentName: document.creatorData?.departmentName || preparer?.departmentName || "MR",
          preparerName: preparer?.fullName || document.preparerName || "Unknown",
          approverName: approver?.fullName || document.approverName || "Pending",
          issuerName: issuer?.fullName || document.issuerName || "Pending",
          location: document.location || document.creatorData?.location || preparer?.location || ""
        };
        console.log("Converting Word to PDF with enriched data for control copy:", controlCopy.copyNumber);
        const cacheKey = `${document.id}_rev${document.revisionNo}_cc${controlCopy.copyNumber}`;
        pdfPath = await getCachedOrGeneratePdf(cacheKey, fullWordPath, enrichedDocument, controlCopyInfo);
        console.log("PDF conversion successful:", pdfPath);
      } catch (err) {
        console.error("PDF conversion error:", err);
        storage.createNotification({
          userId,
          documentId: document.id,
          message: `PDF conversion failed for "${document.docName}".Please contact administrator.`,
          type: "system_error"
        }).catch(() => {
        });
        const debugMsg = `[PDF Error] Document ${document.id} (${document.docNumber}): ${err.message}${err.stack ? "\n" + err.stack : ""} `;
        try {
          const fs5 = await import("fs");
          fs5.appendFileSync("c:\\inetpub\\wwwroot\\dms\\debug.log", `[${(/* @__PURE__ */ new Date()).toISOString()}] ${debugMsg} 
`);
        } catch (e) {
        }
        const message = err.message.includes(".docx") ? err.message : "Failed to convert Word to PDF. Please check the document file and try again.";
        return res.status(500).json({ message });
      }
      try {
        console.log("Reading PDF file:", pdfPath);
        const pdfBuffer = await fsPromises.readFile(pdfPath);
        if (pdfBuffer.length === 0) {
          throw new Error("PDF file is empty");
        }
        console.log("Sending PDF response, size:", pdfBuffer.length);
        const { download } = req.query;
        res.setHeader("Content-Type", "application/pdf");
        if (download === "true") {
          const fileName = `${document.docNumber}_${document.docName}_v${document.revisionNo}.pdf`.replace(/[/\\?%*:|"<>]/g, "-");
          res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
        } else {
          res.setHeader("Content-Disposition", 'inline; filename="document.pdf"');
        }
        res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        res.setHeader("Pragma", "no-cache");
        res.setHeader("Expires", "0");
        res.setHeader("Content-Length", pdfBuffer.length.toString());
        res.setHeader("Content-Security-Policy", "default-src 'none'; frame-ancestors 'self'; img-src 'self' data:; style-src 'unsafe-inline';");
        res.setHeader("X-Content-Type-Options", "nosniff");
        res.setHeader("X-Frame-Options", "SAMEORIGIN");
        res.send(pdfBuffer);
      } catch (err) {
        console.error("PDF file read error (print):", err);
        return res.status(500).json({ message: "PDF file not found or unreadable after conversion." });
      }
    } catch (error) {
      console.error("Print endpoint error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/documents/:id/print", async (req, res) => {
    try {
      const { userId, version } = req.body;
      if (!userId || typeof userId !== "string" || userId.trim() === "") {
        return res.status(400).json({ message: "userId is required and must be a non-empty string." });
      }
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      let document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      const originalDocNumber = document.docNumber;
      const allIssuedDocs = await storage.getDocumentsByStatus("issued");
      const allVersions = allIssuedDocs.filter((d) => d.docNumber === originalDocNumber);
      if (allVersions.length === 0) {
        return res.status(404).json({ message: "No issued versions found for this document" });
      }
      const latestVersion = allVersions.reduce((latest, current) => {
        return current.revisionNo > latest.revisionNo ? current : latest;
      }, allVersions[0]);
      if (version !== void 0) {
        const requestedVersion = parseInt(version, 10);
        if (isNaN(requestedVersion)) {
          return res.status(400).json({ message: "Invalid version parameter" });
        }
        const userRole = user.role?.toLowerCase() || "";
        if (!user.masterCopyAccess && !["approver", "creator", "issuer", "admin"].includes(userRole)) {
          return res.status(403).json({ message: "Access denied. Only master copy users can print specific versions." });
        }
        const requestedDoc = allVersions.find((d) => d.revisionNo === requestedVersion);
        if (!requestedDoc) {
          return res.status(404).json({ message: `Version ${requestedVersion} not found` });
        }
        document = await storage.getDocument(requestedDoc.id) || requestedDoc;
      } else if (!user.masterCopyAccess && !["approver", "creator", "issuer", "admin"].includes(user.role?.toLowerCase() || "") && document.id !== latestVersion.id) {
        return res.status(403).json({ message: "Access denied. Only the latest version can be printed. Please contact administrator for previous versions." });
      }
      if (document.status !== "issued") {
        return res.status(403).json({ message: "Only issued documents can be printed" });
      }
      if (!document.wordFilePath) {
        return res.status(404).json({ message: "No Word file uploaded for this document" });
      }
      const fullPath = path2.join(pdfService.uploadsDir, path2.basename(document.wordFilePath));
      try {
        await fsPromises.access(fullPath);
      } catch (fileError) {
        return res.status(400).json({ message: "Document file not found or inaccessible. Cannot generate PDF." });
      }
      if (user.role !== "admin") {
        const alreadyPrinted = await storage.hasUserPrintedDocument(userId, document.id);
        if (alreadyPrinted) {
          return res.status(403).json({
            message: "Access Denied: This document has already been printed by you. Multiple prints are not allowed as per system policy. Please contact your administrator if you need another copy."
          });
        }
      }
      let pdfPath;
      try {
        const controlCopy = await storage.createControlCopy({
          documentId: document.id,
          userId,
          actionType: "print"
        });
        await storage.createPrintLog({
          documentId: document.id,
          userId,
          controlCopyId: controlCopy.id,
          medium: "PDF"
        });
        const controlCopyInfo = {
          userId: user.id,
          userFullName: user.fullName,
          controlCopyNumber: controlCopy.copyNumber,
          date: (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB")
        };
        const preparer = await storage.getUser(document.preparedBy);
        const approver = document.approvedBy ? await storage.getUser(document.approvedBy) : null;
        const issuer = document.issuedBy ? await storage.getUser(document.issuedBy) : null;
        const depts = await storage.getDocumentDepartments(document.id);
        const departmentNames = depts.map((d) => d.name);
        const enrichedDocument = {
          ...document,
          departments: depts,
          departmentNames,
          creatorDepartmentName: document.creatorData?.departmentName || preparer?.departmentName || "MR",
          preparerName: preparer?.fullName || document.preparerName || "Unknown",
          approverName: approver?.fullName || document.approverName || "Pending",
          issuerName: issuer?.fullName || document.issuerName || "Pending",
          location: document.location || document.creatorData?.location || preparer?.location || ""
        };
        pdfPath = await pdfService.convertWordToPDF(fullPath, enrichedDocument, controlCopyInfo);
        const pdfBuffer = await fsPromises.readFile(pdfPath);
        res.setHeader("Content-Type", "application/pdf");
        res.setHeader("Content-Disposition", 'inline; filename="print_copy.pdf"');
        res.send(pdfBuffer);
      } catch (err) {
        console.error("PDF printing error:", err);
        return res.status(500).json({ message: "Failed to generate print copy." });
      }
    } catch (error) {
      console.error("Print endpoint error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/documents/:id/download-pdf", async (req, res) => {
    const REQUEST_ID = Math.random().toString(36).substring(7);
    try {
      debugLog2(`[Download - ${REQUEST_ID}] New PDF download request for ID: ${req.params.id} `);
      const { userId } = req.body;
      if (!userId) return res.status(400).json({ message: "userId is required" });
      const user = await storage.getUser(userId);
      if (!user) return res.status(404).json({ message: "User not found" });
      let document = await storage.getDocument(req.params.id);
      if (!document) return res.status(404).json({ message: "Document not found" });
      if (document.status !== "issued" && !(document.status === "approved" && user.role === "issuer")) {
        return res.status(403).json({ message: "Access denied" });
      }
      if (!document.wordFilePath) return res.status(404).json({ message: "No Word file found" });
      const wordBasename = path2.basename(document.wordFilePath);
      const fullWordPath = path2.join(pdfService.uploadsDir, wordBasename);
      debugLog2(`[Download - ${REQUEST_ID}] Looking for file: ${fullWordPath} `);
      try {
        await fsPromises.access(fullWordPath);
      } catch (e) {
        debugLog2(`[Download - ${REQUEST_ID}] File NOT found: ${fullWordPath} `);
        return res.status(400).json({ message: "Word file not found on server storage." });
      }
      const controlCopy = await storage.createControlCopy({
        documentId: document.id,
        userId,
        actionType: "download"
      });
      const controlCopyInfo = {
        userId: user.id,
        userFullName: user.fullName,
        controlCopyNumber: controlCopy.copyNumber,
        date: (/* @__PURE__ */ new Date()).toLocaleDateString("en-GB")
      };
      const depts = await storage.getDocumentDepartments(document.id);
      const preparer = await storage.getUser(document.preparedBy);
      const approver = document.approvedBy ? await storage.getUser(document.approvedBy) : null;
      const issuer = document.issuedBy ? await storage.getUser(document.issuedBy) : null;
      const enrichedDocument = {
        ...document,
        departments: depts,
        departmentNames: depts.map((d) => d.name),
        creatorDepartmentName: document.creatorData?.departmentName || preparer?.departmentName || "MR",
        preparerName: preparer?.fullName || document.preparerName || "Unknown",
        approverName: approver?.fullName || document.approverName || "Pending",
        issuerName: issuer?.fullName || document.issuerName || "Pending",
        location: document.location || document.creatorData?.location || preparer?.location || ""
      };
      debugLog2(`[Download - ${REQUEST_ID}] Starting conversion v2.1...`);
      const pdfPath = await pdfService.convertWordToPDF(fullWordPath, enrichedDocument, controlCopyInfo);
      const pdfBuffer = await fsPromises.readFile(pdfPath);
      if (!pdfBuffer || pdfBuffer.length < 100) {
        throw new Error(`Generated PDF is suspiciously small(${pdfBuffer?.length || 0} bytes)`);
      }
      debugLog2(`[Download - ${REQUEST_ID}]Success! Sending ${pdfBuffer.length} bytes`);
      const safeDocNumber = (document.docNumber || "document").trim().replace(/[/\\?%*:|"<>]/g, "-");
      const safeDocName = (document.docName || "").trim().replace(/[/\\?%*:|"<>]/g, "-");
      const fileName = `${safeDocNumber}_${safeDocName}_v${document.revisionNo}.pdf`;
      res.setHeader("Content-Type", "application/pdf");
      res.setHeader("Content-Disposition", `attachment; filename="${fileName}"`);
      res.setHeader("Content-Length", pdfBuffer.length);
      res.setHeader("Cache-Control", "no-cache");
      res.send(pdfBuffer);
    } catch (err) {
      const errorMsg = `[Download - ${REQUEST_ID}] CRITICAL ERROR: ${err.message} `;
      console.error(errorMsg);
      debugLog2(errorMsg);
      res.status(500).json({ message: "Internal server error during PDF generation. " + err.message });
    }
  });
  app2.get("/api/reports/print-logs", async (req, res) => {
    try {
      const { documentId, userId } = req.query;
      let printLogs;
      if (documentId) {
        printLogs = await storage.getPrintLogsByDocument(documentId);
      } else if (userId) {
        printLogs = await storage.getPrintLogsByUser(userId);
      } else {
        return res.status(400).json({ message: "documentId or userId query parameter is required" });
      }
      const logsWithDetails = await Promise.all(
        printLogs.map(async (log2) => {
          const document = await storage.getDocument(log2.documentId);
          const user = await storage.getUser(log2.userId);
          const controlCopy = await storage.getControlCopiesByDocument(log2.documentId);
          const userCopy = controlCopy.find((cc) => cc.id === log2.controlCopyId);
          return {
            ...log2,
            documentName: document?.docName || "Unknown",
            documentNumber: document?.docNumber || "Unknown",
            userName: user?.fullName || "Unknown",
            userEmail: user?.username || "Unknown",
            controlCopyNumber: userCopy?.copyNumber || 0
          };
        })
      );
      res.json(logsWithDetails);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/reports/control-copies", async (req, res) => {
    try {
      const { documentId, userId } = req.query;
      let controlCopies;
      if (documentId) {
        controlCopies = await storage.getControlCopiesByDocument(documentId);
      } else if (userId) {
        controlCopies = await storage.getControlCopiesByUser(userId);
      } else {
        return res.status(400).json({ message: "documentId or userId query parameter is required" });
      }
      const copiesWithDetails = await Promise.all(
        controlCopies.map(async (cc) => {
          const document = await storage.getDocument(cc.documentId);
          const user = await storage.getUser(cc.userId);
          return {
            ...cc,
            documentName: document?.docName || "Unknown",
            documentNumber: document?.docNumber || "Unknown",
            userName: user?.fullName || "Unknown",
            userEmail: user?.username || "Unknown"
          };
        })
      );
      res.json(copiesWithDetails);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents/:docNumber/versions", async (req, res) => {
    try {
      const { userId } = req.query;
      if (!userId) {
        return res.status(400).json({ message: "userId query parameter is required" });
      }
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      const allDocuments = await storage.getDocumentsByStatus("issued");
      const documentVersions = allDocuments.filter((d) => d.docNumber === req.params.docNumber);
      if (user.masterCopyAccess) {
        res.json(documentVersions);
      } else {
        const latestVersion = documentVersions.reduce((latest, current) => {
          return current.revisionNo > latest.revisionNo ? current : latest;
        }, documentVersions[0]);
        res.json([latestVersion]);
      }
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents/:id/revise", async (req, res) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      if (document.status !== "approved" && document.status !== "issued") {
        return res.status(400).json({ message: "Only approved or issued documents can be revised" });
      }
      const departments = await storage.getDocumentDepartments(document.id);
      res.json({
        originalDocument: {
          ...document,
          departments
        },
        revisionData: {
          docName: document.docName,
          docNumber: document.docNumber,
          location: document.location,
          duePeriodYears: document.duePeriodYears,
          previousVersionId: document.id,
          // Auto-set revision date to today
          dateOfIssue: (/* @__PURE__ */ new Date()).toISOString().split("T")[0],
          reasonForRevision: `Revision of ${document.docName} (v${document.revisionNo})`
        }
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents/:id/revisions", async (req, res) => {
    try {
      const document = await storage.getDocument(req.params.id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      const revisions = await storage.getDocumentRevisions(document.docNumber);
      const revisionsWithDetails = await Promise.all(
        revisions.map(async (doc) => {
          const preparer = await storage.getUser(doc.preparedBy);
          const approver = doc.approvedBy ? await storage.getUser(doc.approvedBy) : null;
          const issuer = doc.issuedBy ? await storage.getUser(doc.issuedBy) : null;
          return {
            ...doc,
            preparerName: preparer?.fullName || "Unknown",
            approverName: approver?.fullName || null,
            issuerName: issuer?.fullName || null
          };
        })
      );
      res.json(revisionsWithDetails);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/documents/:id/revision-history", async (req, res) => {
    try {
      const documentId = req.params.id;
      const document = await storage.getDocument(documentId);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }
      const revisionChain = [];
      const allDocs = await storage.getDocumentsByDocNumber(document.docNumber);
      const sortedDocs = allDocs.sort((a, b) => a.revisionNo - b.revisionNo);
      for (const doc of sortedDocs) {
        const preparer = await storage.getUser(doc.preparedBy);
        const approver = doc.approvedBy ? await storage.getUser(doc.approvedBy) : null;
        const issuer = doc.issuedBy ? await storage.getUser(doc.issuedBy) : null;
        const depts = await storage.getDocumentDepartments(doc.id);
        let previousVersionDetails = null;
        if (doc.previousVersionId) {
          const prevDoc = await storage.getDocument(doc.previousVersionId);
          if (prevDoc) {
            previousVersionDetails = {
              id: prevDoc.id,
              docNumber: prevDoc.docNumber,
              revisionNo: prevDoc.revisionNo,
              status: prevDoc.status
            };
          }
        }
        revisionChain.push({
          ...doc,
          preparerName: preparer?.fullName || "Unknown",
          approverName: approver?.fullName || null,
          issuerName: issuer?.fullName || null,
          departments: depts,
          previousVersionDetails,
          isOriginal: doc.revisionNo === 1 || !doc.previousVersionId,
          revisionCount: sortedDocs.length
        });
      }
      res.json({
        documentNumber: document.docNumber,
        totalRevisions: sortedDocs.length,
        revisionChain
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });
  app2.get("/api/admin/revision-activities", async (req, res) => {
    try {
      debugLog2(`[RevisionActivities] Starting grouped revision activities query`);
      const pending = await storage.getDocumentsByStatus("pending");
      const approved = await storage.getDocumentsByStatus("approved");
      const issued = await storage.getDocumentsByStatus("issued");
      const declined = await storage.getDocumentsByStatus("declined");
      const obsolete = await storage.getDocumentsByStatus("obsolete");
      const allDocs = [...pending, ...approved, ...issued, ...declined, ...obsolete];
      const groups = {};
      allDocs.forEach((doc) => {
        if (!doc.docNumber) return;
        if (!groups[doc.docNumber]) groups[doc.docNumber] = [];
        groups[doc.docNumber].push(doc);
      });
      const groupedActivities = await Promise.all(
        Object.entries(groups).map(async ([docNumber, docs]) => {
          const sorted = docs.sort((a, b) => a.revisionNo - b.revisionNo);
          const activities = await Promise.all(
            sorted.map(async (doc) => {
              const preparer = await storage.getUser(doc.preparedBy);
              const approver = doc.approvedBy ? await storage.getUser(doc.approvedBy) : null;
              const issuer = doc.issuedBy ? await storage.getUser(doc.issuedBy) : null;
              const depts = await storage.getDocumentDepartments(doc.id);
              return {
                ...doc,
                preparerName: preparer?.fullName || "Unknown",
                approverName: approver?.fullName || null,
                issuerName: issuer?.fullName || null,
                departments: depts,
                daysSinceCreated: Math.ceil(((/* @__PURE__ */ new Date()).getTime() - new Date(doc.createdAt || 0).getTime()) / (1e3 * 60 * 60 * 24))
              };
            })
          );
          return {
            docNumber,
            docName: activities[0].docName,
            totalRevisions: activities.length,
            activities
          };
        })
      );
      groupedActivities.sort((a, b) => {
        const latestA = Math.max(...a.activities.map((act) => new Date(act.createdAt || 0).getTime()));
        const latestB = Math.max(...b.activities.map((act) => new Date(act.createdAt || 0).getTime()));
        return latestB - latestA;
      });
      res.json({
        totalRevisions: allDocs.length,
        groupedActivities
      });
    } catch (error) {
      console.error("Error in grouped revision activities:", error);
      res.status(500).json({ message: error.message });
    }
  });
  function getRootDir() {
    const candidates = [
      "c:\\inetpub\\wwwroot\\dms",
      process.cwd(),
      path2.resolve(process.cwd(), ".."),
      path2.resolve(__dirname2, ".."),
      path2.resolve(__dirname2, "../..")
    ];
    for (const c of candidates) {
      if (fs3.existsSync(path2.join(c, "client")) && fs3.existsSync(path2.join(c, "index.html"))) {
        return c;
      }
    }
    for (const c of candidates) {
      if (fs3.existsSync(path2.join(c, ".git")) && fs3.existsSync(path2.join(c, "package.json"))) {
        return c;
      }
    }
    for (const c of candidates) {
      if (fs3.existsSync(path2.join(c, ".git"))) {
        return c;
      }
    }
    if (process.cwd().toLowerCase().endsWith("dist")) {
      const parent = path2.resolve(process.cwd(), "..");
      if (fs3.existsSync(path2.join(parent, "package.json"))) {
        return parent;
      }
    }
    return process.cwd();
  }
  function parseGitLogOutput(output) {
    if (!output || !output.trim()) return [];
    return output.trim().split("\n").filter((line) => line.trim().length > 0).map((line) => {
      const parts = line.split("|");
      return {
        hash: parts[0]?.trim() || "",
        author: parts[1]?.trim() || "",
        date: parts[2]?.trim() || "",
        message: parts.slice(3).join("|").trim() || ""
      };
    });
  }
  function parseGitDiffOutput(output) {
    if (!output || !output.trim()) return [];
    return output.trim().split("\n").filter((line) => line.trim().length > 0).map((line) => {
      const parts = line.trim().split(/\s+/);
      const status = parts[0] || "M";
      const file = parts.slice(1).join(" ") || "";
      let statusLabel = "Modified";
      if (status.startsWith("A")) statusLabel = "Added";
      else if (status.startsWith("D")) statusLabel = "Deleted";
      else if (status.startsWith("R")) statusLabel = "Renamed";
      return { status, statusLabel, file };
    });
  }
  function getUpdateHistory() {
    try {
      const rootDir = getRootDir();
      const historyFile = path2.join(rootDir, "update-history.json");
      if (fs3.existsSync(historyFile)) {
        return JSON.parse(fs3.readFileSync(historyFile, "utf8"));
      }
    } catch (e) {
      console.error("Error reading update history:", e);
    }
    return [];
  }
  function saveUpdateHistory(record) {
    try {
      const rootDir = getRootDir();
      const historyFile = path2.join(rootDir, "update-history.json");
      const history = getUpdateHistory();
      history.unshift(record);
      const trimmed = history.slice(0, 30);
      fs3.writeFileSync(historyFile, JSON.stringify(trimmed, null, 2), "utf8");
      const distHistory = path2.join(rootDir, "dist", "update-history.json");
      if (fs3.existsSync(path2.dirname(distHistory))) {
        fs3.writeFileSync(distHistory, JSON.stringify(trimmed, null, 2), "utf8");
      }
    } catch (e) {
      console.error("Error saving update history:", e);
    }
  }
  function syncToIis(srcDir, destDir, logs) {
    if (!fs3.existsSync(destDir)) return;
    logs.push(`[IIS Sync] Starting sync from ${srcDir} to ${destDir}...`);
    function copyRecursive(src, dest) {
      fs3.mkdirSync(dest, { recursive: true });
      const entries = fs3.readdirSync(src, { withFileTypes: true });
      for (const entry of entries) {
        const srcPath = path2.join(src, entry.name);
        const destPath = path2.join(dest, entry.name);
        if (entry.name === ".env" && fs3.existsSync(destPath)) {
          logs.push(`[IIS Sync] Preserved production .env configuration`);
          continue;
        }
        if (["uploads", "pdfs", "node_modules"].includes(entry.name) && fs3.existsSync(destPath)) {
          continue;
        }
        if (entry.isDirectory()) {
          copyRecursive(srcPath, destPath);
        } else {
          fs3.copyFileSync(srcPath, destPath);
        }
      }
    }
    try {
      copyRecursive(srcDir, destDir);
      logs.push(`[IIS Sync] Successfully synced files to IIS directory: ${destDir}`);
    } catch (err) {
      logs.push(`[IIS Sync Warning] ${err.message}`);
    }
  }
  let isSystemUpdating = false;
  app2.get("/api/admin/system/update-status", async (req, res) => {
    try {
      const rootDir = getRootDir();
      let branch = "main";
      try {
        const { stdout } = await execAsync2("git rev-parse --abbrev-ref HEAD", { cwd: rootDir });
        branch = stdout.trim() || "main";
      } catch (e) {
      }
      let currentCommit = { hash: "unknown", author: "", date: "", message: "" };
      try {
        const { stdout } = await execAsync2('git log -1 --pretty=format:"%h|%an|%ad|%s" --date=short', { cwd: rootDir });
        const parsed = parseGitLogOutput(stdout);
        if (parsed.length > 0) currentCommit = parsed[0];
      } catch (e) {
      }
      let fetchSuccess = true;
      let fetchError = "";
      try {
        await execAsync2("git fetch origin", { cwd: rootDir, timeout: 2e4 });
      } catch (e) {
        fetchSuccess = false;
        fetchError = e.message || "Failed to fetch from remote git repository";
      }
      let behindCount = 0;
      let incomingCommits = [];
      let changedFiles = [];
      let remoteCommit = { hash: "", author: "", date: "", message: "" };
      try {
        const { stdout: countOut } = await execAsync2(`git rev-list --count HEAD..origin/${branch}`, { cwd: rootDir });
        behindCount = parseInt(countOut.trim(), 10) || 0;
        if (behindCount > 0) {
          const { stdout: commitsOut } = await execAsync2(`git log HEAD..origin/${branch} --pretty=format:"%h|%an|%ad|%s" --date=short`, { cwd: rootDir });
          incomingCommits = parseGitLogOutput(commitsOut);
          const { stdout: diffOut } = await execAsync2(`git diff --name-status HEAD origin/${branch}`, { cwd: rootDir });
          changedFiles = parseGitDiffOutput(diffOut);
        }
        const { stdout: remoteOut } = await execAsync2(`git log -1 origin/${branch} --pretty=format:"%h|%an|%ad|%s" --date=short`, { cwd: rootDir });
        const parsedRemote = parseGitLogOutput(remoteOut);
        if (parsedRemote.length > 0) remoteCommit = parsedRemote[0];
      } catch (e) {
      }
      let recentHistory = [];
      try {
        const { stdout: histOut } = await execAsync2('git log -10 --pretty=format:"%h|%an|%ad|%s" --date=short', { cwd: rootDir });
        recentHistory = parseGitLogOutput(histOut);
      } catch (e) {
      }
      const updateHistory = getUpdateHistory();
      const iisPath = "c:\\inetpub\\wwwroot\\dms";
      const iisExists = fs3.existsSync(iisPath);
      res.json({
        branch,
        currentCommit,
        remoteCommit: remoteCommit.hash ? remoteCommit : currentCommit,
        hasUpdate: behindCount > 0,
        behindCount,
        incomingCommits,
        changedFiles,
        recentHistory,
        updateHistory,
        fetchSuccess,
        fetchError,
        isUpdating: isSystemUpdating,
        serverInfo: {
          nodeVersion: process.version,
          platform: process.platform,
          uptimeSeconds: Math.floor(process.uptime()),
          iisTargetExists: iisExists,
          iisPath,
          cwd: rootDir
        }
      });
    } catch (error) {
      console.error("Update status error:", error);
      res.status(500).json({ message: error.message });
    }
  });
  app2.post("/api/admin/system/apply-update", async (req, res) => {
    if (isSystemUpdating) {
      return res.status(409).json({ message: "An update or build is currently already running. Please wait for it to complete." });
    }
    isSystemUpdating = true;
    const buildLogs = [];
    const log2 = (msg) => {
      const line = `[${(/* @__PURE__ */ new Date()).toLocaleTimeString()}] ${msg}`;
      buildLogs.push(line);
      console.log(line);
    };
    try {
      const { adminName = "Administrator", forceReset = false, restart = true, rebuildOnly = false } = req.body;
      const rootDir = getRootDir();
      const isClientServer = !fs3.existsSync(path2.join(rootDir, "client", "src"));
      log2(`=======================================================`);
      log2(`Starting software update requested by: ${adminName}`);
      log2(`Working directory: ${rootDir}`);
      log2(`Environment: ${isClientServer ? "Client Server (Production dist package only)" : "Development / Build Server"}`);
      log2(`Mode: ${rebuildOnly ? "Local Rebuild & Sync" : "Update & Deploy"}`);
      let branch = "main";
      try {
        const { stdout } = await execAsync2("git rev-parse --abbrev-ref HEAD", { cwd: rootDir });
        branch = stdout.trim() || "main";
      } catch (e) {
      }
      log2(`Active branch: ${branch}`);
      let prevCommit = { hash: "unknown", author: "", date: "", message: "" };
      try {
        const { stdout } = await execAsync2('git log -1 --pretty=format:"%h|%an|%ad|%s" --date=short', { cwd: rootDir });
        const parsed = parseGitLogOutput(stdout);
        if (parsed.length > 0) prevCommit = parsed[0];
      } catch (e) {
      }
      let updatedCommits = [];
      let changedFiles = [];
      if (isClientServer) {
        log2("Client server detected: deploying dist production bundle only (source code will not be deployed).");
        if (!rebuildOnly) {
          log2("Step 1/2: Fetching latest release package from repository...");
          try {
            await execAsync2(`git fetch origin ${branch}`, { cwd: rootDir, timeout: 3e4 });
            log2("\u2713 Successfully fetched origin");
            try {
              const { stdout: commitsOut } = await execAsync2(`git log HEAD..origin/${branch} --pretty=format:"%h|%an|%ad|%s" --date=short`, { cwd: rootDir });
              updatedCommits = parseGitLogOutput(commitsOut);
            } catch (e) {
            }
            try {
              await execAsync2(`git checkout origin/${branch} -- dist.zip`, { cwd: rootDir });
              log2("\u2713 Checked out latest production dist.zip from repository");
            } catch (coErr) {
              log2(`Note: git checkout dist.zip note: ${coErr.message}`);
            }
          } catch (fetchErr) {
            log2(`Note: Remote fetch notice: ${fetchErr.message}`);
          }
        }
        const distZip = path2.join(rootDir, "dist.zip");
        if (fs3.existsSync(distZip)) {
          log2("Step 2/2: Applying production dist files from dist.zip...");
          try {
            const zip = new AdmZip2(distZip);
            const envPath = path2.join(rootDir, ".env");
            const envBackup = fs3.existsSync(envPath) ? fs3.readFileSync(envPath, "utf8") : null;
            zip.extractAllTo(rootDir, true);
            if (envBackup) {
              fs3.writeFileSync(envPath, envBackup, "utf8");
              log2("\u2713 Preserved production .env settings");
            }
            log2("\u2713 Production dist files successfully updated (clean dist deployment)!");
          } catch (zipErr) {
            log2(`\u26A0 Extraction notice: ${zipErr.message}. Trying PowerShell fallback...`);
            await execAsync2(`powershell -NoProfile -Command "Expand-Archive -Path dist.zip -DestinationPath . -Force"`, { cwd: rootDir, timeout: 3e4 });
          }
        } else {
          log2("Step 2/2: Production dist package is up-to-date.");
        }
      } else {
        if (!rebuildOnly) {
          log2("Step 1/4: Fetching latest code from GitHub remote repository...");
          await execAsync2("git fetch origin", { cwd: rootDir, timeout: 3e4 });
          log2("\u2713 Successfully fetched origin");
          try {
            const { stdout: commitsOut } = await execAsync2(`git log HEAD..origin/${branch} --pretty=format:"%h|%an|%ad|%s" --date=short`, { cwd: rootDir });
            updatedCommits = parseGitLogOutput(commitsOut);
            const { stdout: diffOut } = await execAsync2(`git diff --name-status HEAD origin/${branch}`, { cwd: rootDir });
            changedFiles = parseGitDiffOutput(diffOut);
            if (updatedCommits.length > 0) {
              log2(`Found ${updatedCommits.length} incoming commit(s) and ${changedFiles.length} file(s) changed.`);
            }
          } catch (e) {
          }
          log2(`Step 2/4: Synchronizing repository with origin/${branch}...`);
          try {
            await execAsync2(`git reset --hard origin/${branch}`, { cwd: rootDir });
            log2(`\u2713 Repository cleanly synchronized to origin/${branch}`);
          } catch (resetErr) {
            log2(`\u26A0 Git reset notice: ${resetErr.message}. Trying pull...`);
            try {
              await execAsync2(`git pull origin ${branch} --allow-unrelated-histories -X theirs`, { cwd: rootDir });
              log2(`\u2713 Git pull completed`);
            } catch (pullErr) {
              await execAsync2(`git fetch origin ${branch}`, { cwd: rootDir });
              await execAsync2(`git reset --hard FETCH_HEAD`, { cwd: rootDir });
              log2(`\u2713 Repository synchronized to FETCH_HEAD`);
            }
          }
        } else {
          log2("Step 1 & 2 skipped (Rebuild requested without pulling remote git changes)");
        }
        log2("Step 3/4: Compiling frontend client assets (Vite production build)...");
        const { stdout: viteOut } = await execAsync2("npx vite build", { cwd: rootDir, timeout: 18e4, maxBuffer: 10 * 1024 * 1024 });
        log2("\u2713 Frontend build completed successfully.");
        if (viteOut) {
          const lines = viteOut.split("\n").filter((l) => l.includes("built in") || l.includes("dist/public"));
          lines.forEach((l) => log2(`  ${l.trim()}`));
        }
        log2("Compiling Node.js backend server and generating deployment bundle...");
        await execAsync2("npx esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist", { cwd: rootDir, timeout: 6e4 });
        log2("\u2713 Backend bundle compiled to dist/index.js");
        const prepScript = path2.join(rootDir, "scripts", "prepare-deployment.js");
        if (fs3.existsSync(prepScript)) {
          await execAsync2("node scripts/prepare-deployment.js", { cwd: rootDir, timeout: 6e4 });
          log2("\u2713 Deployment package, IIS web.config, production dist.zip, and dependencies prepared");
        }
        const iisPath = "c:\\inetpub\\wwwroot\\dms";
        const distDir = path2.join(rootDir, "dist");
        if (fs3.existsSync(iisPath) && path2.resolve(rootDir).toLowerCase() !== path2.resolve(iisPath).toLowerCase()) {
          log2(`Step 4/4: Syncing ONLY dist files directly to IIS folder (${iisPath})...`);
          syncToIis(distDir, iisPath, buildLogs);
        } else {
          log2("Step 4/4: Local dist package updated. IIS reverse proxy serves the updated application.");
        }
      }
      let newCommit = prevCommit;
      try {
        const { stdout } = await execAsync2('git log -1 --pretty=format:"%h|%an|%ad|%s" --date=short', { cwd: rootDir });
        const parsed = parseGitLogOutput(stdout);
        if (parsed.length > 0) newCommit = parsed[0];
      } catch (e) {
      }
      log2(`Active commit is now: ${newCommit.hash} - "${newCommit.message}"`);
      log2("\u{1F389} System update completed successfully!");
      log2(`=======================================================`);
      const updateRecord = {
        id: `update-${Date.now()}`,
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        adminName,
        previousCommit: prevCommit,
        newCommit,
        updatedCommits: updatedCommits.length > 0 ? updatedCommits : [newCommit],
        changedFiles,
        status: "success",
        logs: buildLogs.join("\n")
      };
      saveUpdateHistory(updateRecord);
      isSystemUpdating = false;
      res.json({
        success: true,
        message: "Software successfully updated!",
        previousCommit: prevCommit,
        newCommit,
        updatedCommits: updateRecord.updatedCommits,
        changedFiles,
        logs: buildLogs.join("\n"),
        restartTriggered: restart
      });
      if (restart) {
        setTimeout(() => {
          log2("[Supervision] Gracefully recycling server process to reload fresh backend code...");
          process.exit(0);
        }, 3e3);
      }
    } catch (error) {
      isSystemUpdating = false;
      log2(`\u274C Update failed with error: ${error.message}`);
      console.error("System update error:", error);
      res.status(500).json({
        success: false,
        message: `Update failed: ${error.message}`,
        logs: buildLogs.join("\n")
      });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs4 from "fs";
import path4 from "path";
import { fileURLToPath as fileURLToPath4 } from "url";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path3 from "path";
import { fileURLToPath as fileURLToPath3 } from "url";
var __dirname3 = path3.dirname(fileURLToPath3(import.meta.url));
var vite_config_default = defineConfig({
  plugins: [
    react()
  ],
  resolve: {
    alias: {
      "@": path3.resolve(__dirname3, "client", "src"),
      "@shared": path3.resolve(__dirname3, "shared"),
      "@assets": path3.resolve(__dirname3, "attached_assets")
    }
  },
  root: path3.resolve(__dirname3, "client"),
  build: {
    outDir: path3.resolve(__dirname3, "dist", "public"),
    emptyOutDir: true
  },
  server: {
    hmr: {
      overlay: false
      // Disable HMR overlay to prevent runtime error messages
    },
    fs: {
      strict: true,
      deny: ["**/.*"]
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var __dirname4 = path4.dirname(fileURLToPath4(import.meta.url));
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path4.resolve(
        __dirname4,
        "..",
        "client",
        "index.html"
      );
      let template = await fs4.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path4.resolve(__dirname4, "public");
  if (!fs4.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (req, res) => {
    if (req.originalUrl.startsWith("/api") || req.baseUrl.startsWith("/api") || req.path.startsWith("/api")) {
      return res.status(404).json({ message: `API route not found: ${req.method} ${req.originalUrl}. Server process may need to be restarted.` });
    }
    res.setHeader("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");
    res.sendFile(path4.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  }
}));
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path5 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path5.startsWith("/api")) {
      let logLine = `${req.method} ${path5} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  try {
    console.log("Initializing PDF service...");
    await pdfService.initialize();
    console.log("PDF service initialized successfully");
    console.log("Testing Puppeteer availability...");
    try {
      const puppeteer3 = await import("puppeteer");
      const browser = await puppeteer3.default.launch({
        headless: true,
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH || void 0,
        args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage", "--disable-gpu"]
      });
      await browser.close();
      console.log("Puppeteer test successful - Chrome found");
    } catch (puppeteerError) {
      console.warn("Puppeteer test failed:", puppeteerError);
    }
    const server = await registerRoutes(app);
    console.log("Routes registered successfully");
    try {
      console.log("Checking for superseded issued documents with overlapping locations...");
      await storage.cleanUpAllSupersededIssuedDocuments();
    } catch (cleanupErr) {
      console.warn("Initial cleanup of superseded documents warning:", cleanupErr);
    }
    app.use((err, _req, res, _next) => {
      const status = err.status || err.statusCode || 500;
      const message = err.message || "Internal Server Error";
      res.status(status).json({ message });
      throw err;
    });
    if (app.get("env") === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }
    const port = parseInt(process.env.PORT || "5000", 10);
    const host = process.env.HOST || "0.0.0.0";
    server.listen({
      port,
      host
    }, () => {
      log(`serving on port ${port} on host ${host}`);
    });
  } catch (initError) {
    console.error("Server initialization failed:", initError);
    process.exit(1);
  }
})();
