# DMS Deployment Package (IIS + SQL Server)

## Files Included:
- `app.js` - Entry point for Node.js
- `index.js` - Built server code
- `public/` - Frontend static files
- `package.json` - Production dependencies only
- `web.config` - IIS reverse proxy configuration
- `.env` - SQL Server connection settings
- `uploads/` - User uploaded files (if any)
- `pdfs/` - Generated PDFs (if any)

## IIS Deployment Steps:

1. **Create DMS database in SQL Server** - Run scripts/create-tables.sql

2. **Install dependencies** in the dist folder:
   ```
   cd dist
   npm install --production
   ```

3. **Configure .env** with your SQL Server connection settings

4. **Start the Node.js server**:
   ```
   node app.js
   ```

5. **Configure IIS**:
   - Point the IIS site physical path to this dist folder
   - Ensure URL Rewrite and ARR modules are installed
   - Enable ARR proxy in IIS Server level

6. **Test** by visiting your IIS URL
